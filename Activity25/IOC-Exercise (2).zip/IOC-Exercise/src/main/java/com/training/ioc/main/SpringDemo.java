/**
 * SpringDemo
 * 
 * demo for Spring Inversion of control
 * 
 * 12/10/2020
 */
package com.training.ioc.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.ioc.bean.Organizer;

/**
 * 
 * @author Jasir
 * IOC demo
 */
public class SpringDemo {

	public static void main(String[] args) {
		
		/* loading the definitions from the given XML file */
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Organizer org =  context.getBean("competionOrganizer",Organizer.class);
		
		org.sayGreetings();

	}

}
