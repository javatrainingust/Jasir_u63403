/**
 * Organizer
 * 
 * Organizer for Spring World Talent Competition
 * 
 * 12/10/2020
 */
package com.training.ioc.bean;

import org.springframework.stereotype.Component;

/**
 * 
 * @author Jasir
 * Bean class for organizer
 */

@Component("competionOrganizer")
public class Organizer {

	/**
	 * default constructor 
	 */
	public Organizer() {
		
		System.out.println("Inside Organizer constructor");
	}
	
	/**
	 * welcome the participant
	 */
	public void sayGreetings() {
		System.out.println("Welcome to the talent competion");
	}
}
