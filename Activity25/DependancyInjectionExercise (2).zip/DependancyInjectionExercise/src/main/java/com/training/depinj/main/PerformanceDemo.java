/**
 * PerformanceDemo
 * 
 * Dependency injection demo
 * 
 * 12/10/2020
 */
package com.training.depinj.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.depinj.model.Instrumentalist;
import com.training.depinj.model.Singer;
/**
 * 
 * @author Jasir
 * Demo for Dependency injection through constructor
 */
public class PerformanceDemo {

	public static void main(String[] args) {
		
		/* loading the definitions from the given XML file */
		
		/* Dependency Injection through constructor*/
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		 
		Singer singer =  context.getBean("singObj",Singer.class);
		
		singer.perform();
		
		/* Dependency Injection through setter method*/
		Instrumentalist instrumentalist = context.getBean("instrumentalistObj", Instrumentalist.class);
		
		instrumentalist.perform();

	}

}
