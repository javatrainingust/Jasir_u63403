/**
 * Instrument 
 * 
 * interface for Instrument 
 * 
 * 12/10/2020
 * 
 */
package com.training.depinj.util;

/**
 * interface for Instrument 
 * @author Jasir
 *
 */
public interface Instrument {

	public void play();
	
}
