/***
 * Instrumentalist
 * 
 * Demo for dependency injection through setter method
 * 
 * 12/10/2020
 */
package com.training.depinj.model;

import com.training.depinj.util.Performer;
/**
 * Demo for dependency injection through setter method
 * @author Jasir
 *
 */
public class Instrumentalist implements Performer {

	Saxophone saxophon;
	
	/**
	 * get method
	 * @return
	 */
	public Saxophone getSaxophon() {
		return saxophon;
	}

	/**
	 * setter method for dep-injection
	 * @param saxophon
	 */
	public void setSaxophon(Saxophone saxophon) {
		this.saxophon = saxophon;
	}

	/**
	 * implementation
	 */
	public void perform() {
		
		this.saxophon.play();
	}

}
