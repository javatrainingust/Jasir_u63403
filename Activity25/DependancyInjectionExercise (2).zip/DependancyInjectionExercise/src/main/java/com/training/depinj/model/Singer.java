/**
 * Singer
 * 
 * A class for handle singer data
 * 
 * 12/10/2020
 * 
 */
package com.training.depinj.model;

import com.training.depinj.util.Performer;
/**
 * 
 * @author Jasir
 * Singer class
 */
public class Singer implements Performer {

	private String song;

	/**
	 * Constructor method for dependency injection
	 * @param song
	 */
	public Singer(String song) {
		super();
		this.song = song;
	}

	/**
	 * implementation of perform method
	 */
	public void perform() {
	
		System.out.println("The Song is "+this.song);
		
	}

}
