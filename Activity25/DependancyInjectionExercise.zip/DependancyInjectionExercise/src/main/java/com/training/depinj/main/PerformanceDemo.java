/**
 * PerformanceDemo
 * 
 * Dependency injection demo
 * 
 * 12/10/2020
 */
package com.training.depinj.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.depinj.model.Instrumentalist;
/**
 * 
 * @author Jasir
 * Demo for Dependency injection through constructor
 */
public class PerformanceDemo {

	public static void main(String[] args) {
		
		/* loading the definitions from the given XML file */
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		
		Instrumentalist instrumentalist = context.getBean("instrumentalistObj", Instrumentalist.class);
		
		instrumentalist.perform();


	}

}
