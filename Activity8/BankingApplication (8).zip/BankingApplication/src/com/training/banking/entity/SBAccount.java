package com.training.banking.entity;

import com.training.banking.interfaces.ICalculateInterest;

public class SBAccount extends Account {

	private float rate;
	private int time;
	
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	
	/**overriding method for calculate interest*/
	public void calculateInterest(ICalculateInterest calcs) {
		
		float interesrt = calcs.calculateInterest(this.getAccountBalance(),rate);
		System.out.println("your SBAccount will have RS "+interesrt+ " as interest  with rate "+rate);
		
	}
}
