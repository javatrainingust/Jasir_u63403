/**
 * GenericService
 * 
 * type cast 
 *
 * 29/09/2020
 * 
*/
package com.training.banking.service;

import com.training.banking.entity.Account;
import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.util.InterestCalculator;

public class GenericService {
	
	public static void main(String[] args) {
		SBAccount sbac = new SBAccount();
		InterestCalculator calculator = new InterestCalculator();
		FDAccount fdac = new FDAccount();
		
		sbac.setRate(.5f);
		sbac.setAccountHolderName("raj");
		sbac.setAccountNumber(123654);
		sbac.setTime(1);
		
		fdac.setAccountHolderName("sam");
		fdac.setTenure(1);
		fdac.setRate(0.7f);
		
		Account [] ac = {new Account(),sbac,fdac};
		
		for(Account account: ac) {
			
			account.calculateInterest(calculator);
			if(account instanceof FDAccount) {
				FDAccount fdAccount = (FDAccount) account;
				System.out.println("AC balane "+fdAccount.getAccountBalance());
			}
		}
		
	}
}
