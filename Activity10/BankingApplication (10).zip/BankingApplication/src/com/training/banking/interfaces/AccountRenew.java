/**
 * AccountRenew
 * 
 * Interface for renew. reduce the dependency
 *
 * 28/09/2020
 * 
*/
package com.training.banking.interfaces;

public interface AccountRenew {
	
	public void autoRenewal(int tenure);

}
