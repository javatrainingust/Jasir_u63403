/**
 * InterestCalculator
 * 
 * Class for calculate interests
 *
 * 29/09/2020
 * 
*/


package com.training.banking.util;
import com.training.banking.interfaces.ICalculateInterest;

/**class for calculate interest. its implements an interface for reduce dependency */

public class InterestCalculator implements ICalculateInterest {

	/**overloading method for FDAccount*/
	public Float calculateInterest(float principle,float rate,int time) {
	
		float intrest = principle*time*rate; 
		
		return intrest;
	}
	
	/**overloading method for SBAccount*/
	public Float calculateInterest(float principle,float rate) {
		
		int time =1;   							/*tenure*/
		float intrest = principle*time*rate; 
		
		return intrest;
		
	}
		
	
}
