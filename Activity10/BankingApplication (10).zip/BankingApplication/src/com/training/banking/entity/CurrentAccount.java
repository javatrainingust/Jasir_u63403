/**
 * InterestCalculator
 * 
 * Entity class for handle the current account account
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

/**sub class for current account derived from account class */
public class CurrentAccount extends Account {

	private float overDraftLimit;

	
	/**get the limit of over draft*/
	public float getOverDraftLimit() {
		return overDraftLimit;
	}
	
	/**Set the limit of over draft*/
	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	
	
}
