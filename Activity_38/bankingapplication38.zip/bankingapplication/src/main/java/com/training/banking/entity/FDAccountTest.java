package com.training.banking.entity;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.training.banking.interfaces.AccountRenew;

class FDAccountTest {

	@Test
	void testAutoRenewal() {
		
		int expectedValue = 2021;
		FDAccount fdac1 = new FDAccount();
		fdac1.autoRenew(1);
		int actualValue = fdac1.getMaturity_date();
		assertEquals(expectedValue, actualValue);
	}

}
