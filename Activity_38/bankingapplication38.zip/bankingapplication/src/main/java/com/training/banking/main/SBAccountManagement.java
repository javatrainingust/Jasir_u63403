/**
 * SBAccountManagement
 * 
 * Main method for SBAccount 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.main;

import com.training.banking.service.SBAccountservice;
/**
 * Main class
 */
public class SBAccountManagement {

	public static void main(String[] args) {
		SBAccountservice sbAccount =  new SBAccountservice();
		System.out.println("\nAll Accounts\n");
		sbAccount.getAllSBAccounts();
		System.out.println("\nAfter Sorting bye account name\n");
		sbAccount.getAllSavingsAccountsSortedByNames();
		System.out.println("\nAfter Sorting bye account balance\n");
		sbAccount.getAllSavingsAccountsSortedByBalance();
		System.out.println("\nOne by account number\n");
		sbAccount.getSBAccountByAccountNum(123456711);
		sbAccount.deleteSBAccount(123456710);
		System.out.println("\nAfter Delete\n");
		sbAccount.getAllSBAccounts();
	}

}
