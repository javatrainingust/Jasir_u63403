package com.training.banking.main;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.service.CurrentAccountService;

public class CurrentAccountAddDemo {

	public static void main(String[] args) {
		
		CurrentAccountService service = new CurrentAccountService();
		
		service.addCurrentAccount(new CurrentAccount(123456730, "Sabith", 10000.0f, 5000.0f));
		service.addCurrentAccount(new CurrentAccount(123456731, "Arun", 15000.0f, 8000.0f));
		service.addCurrentAccount(new CurrentAccount(123456732, "Anoop", 20000.0f, 6000.0f));
		service.addCurrentAccount(new CurrentAccount(123456734, "Hisam", 11000.0f, 7000.0f));
		service.addCurrentAccount(new CurrentAccount(123456732, "Alan", 20300.0f, 65000.0f));
		System.out.println("Printing all CurrentAccounts");	
		service.getAllCurAccounts();
		System.out.println("---------------------------------------------");	
		service.updateCurrentAccount(new CurrentAccount(123456734, "Hisam puthalath", 11000.0f, 7000.0f));
		
		System.out.println("Printing all updated CurrentAccounts");	
		
		service.getAllCurAccounts();

	}

}
