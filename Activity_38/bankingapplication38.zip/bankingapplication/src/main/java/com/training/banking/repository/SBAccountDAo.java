/**
 * FDAccountDao
 * 
 * Interface for SBAccount repository 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.repository;

import java.util.List;

import com.training.banking.entity.SBAccount;
/**
 * Interface for SB Account
 */
public interface SBAccountDAo {

	public List<SBAccount> getAllSavingsAccounts();
	public SBAccount getSBAccountByAccountNum(int acNumber);
	public void deleteSavingsAccount(int acNumber);
	public boolean addSavingsAccount(SBAccount sbAccount);
	public void updateSavingsAccount(SBAccount sbAccount);
}
