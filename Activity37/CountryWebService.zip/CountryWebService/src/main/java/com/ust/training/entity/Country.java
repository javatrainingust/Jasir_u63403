/**
 * Country
 * country entity class
 * 22/10/2020
 */
package com.ust.training.entity;
/**
 * Country details model class
 * @author Jasir
 *
 */
public class Country {

	private String countryCode;
	private String countryName;
	private String countryRegion;
	
	/**
	 * default constructor
	 */
	public Country() {
		super();
	}
	/**
	 * get country code
	 * @return
	 */
	public String getCountryCode() {
		return countryCode;
	}
	/**
	 * set country code
	 * @param countryCode
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	/**
	 * get country name
	 * @return
	 */
	public String getCountryName() {
		return countryName;
	}
	/**
	 * set country name
	 * @param countryName
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	/**
	 * get cuntry region
	 * @return
	 */
	public String getCountryRegion() {
		return countryRegion;
	}
	/**
	 * set county region
	 * @param countryRegion
	 */
	public void setCountryRegion(String countryRegion) {
		this.countryRegion = countryRegion;
	}

	/**
	 * convert to string
	 */
	@Override
	public String toString() {
		return "Country [countryCode=" + countryCode + ", countryName=" + countryName + ", countryRegion="
				+ countryRegion + "]";
	}
	
	
	
}
