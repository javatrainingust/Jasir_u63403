package com.ust.training.controler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.training.entity.Country;

@RestController
public class CountryController {


	Map<String,Country> countryDatabase = new HashMap<String,Country>();
	
	
	
	
	@RequestMapping(value="/countries/dummy",method=RequestMethod.GET) 
	public String getCountry() {
		
		Country country = new Country();
		
		country.setCountryCode("IN");
		country.setCountryName("India");
		country.setCountryRegion("Asia");
		
        Country country1 = new Country();
		
		country1.setCountryCode("UK");
		country1.setCountryName("London");
		country1.setCountryRegion("Europ");
		
		countryDatabase.put("UK", country1);
		countryDatabase.put("IN", country);
		return "Success";	
		
		
		
	}
	
	@RequestMapping(value="/countries/{id}",method=RequestMethod.GET) 
	public Country getEmployee(@PathVariable String id) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(id)) {
			country = countryDatabase.get(id);	
		}
				
		return country;
	}
	
	@RequestMapping(value="/countries",method=RequestMethod.GET) 
	public List<Country> getAllEmployees() {
		
		List<Country> country  = new ArrayList<Country>();
		
		Set<String> employeeIdKeys = countryDatabase.keySet();
		
		for(String i: employeeIdKeys) {
			
			country.add(countryDatabase.get(i));
		}
				
		return country;	
		
		
		
	}
	
	@RequestMapping(value="/countries",method=RequestMethod.POST) 
	public Country createEmployee(@RequestBody Country country) {
		
		System.out.println("employee id: "+ country.getCountryCode());
			
		countryDatabase.put(country.getCountryCode(), country);
	
		return country;
		
		
	}
	
	@RequestMapping(value="/countries/{id}",method=RequestMethod.DELETE)
	public Country deleteEmployee(@PathVariable String id) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(id)) {
			country = countryDatabase.get(id);
			
			countryDatabase.remove(id);
		}
		return country;
		
		
		
	}
	
	@RequestMapping(value="/countries/{id}",method=RequestMethod.PUT)
	public Country updateEmployee(@PathVariable String id,@RequestBody Country modifiedCountry ) {
		
		Country  country = new Country();
		
		if(countryDatabase.containsKey(id)) {
			
			country = countryDatabase.get(id);
			country.setCountryName(modifiedCountry.getCountryName());
			
			country.setCountryRegion(modifiedCountry.getCountryRegion());
			
		}
				
		return country;
	}
	
}
