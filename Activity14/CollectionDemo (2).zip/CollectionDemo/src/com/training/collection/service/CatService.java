/**
 * CatService
 * 
 * HashSet Implementation for Cat
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.HashSet;
import java.util.Set;

import com.training.collection.entity.Cat;

public class CatService {

	public static void main(String[] args) {
		
		Set<Cat> catSet = new HashSet<Cat>();
		
		Cat cat1 = new Cat("Lilly", 1);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("Mainkutty", 2);
		Cat cat4 = new Cat("pinky", 3);

		catSet.add(cat1);
		catSet.add(cat2);
		catSet.add(cat3);
		catSet.add(cat4);
		
		for (Cat cats: catSet) {
			System.out.println(cats);
		}
		
		
		}
	

}
