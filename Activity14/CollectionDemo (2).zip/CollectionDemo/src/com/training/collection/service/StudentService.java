/**
 * StudentService
 * 
 * HashSet Implementation
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.HashSet;
import java.util.Set;

public class StudentService {

	public static void main(String[] args) {
	
		Set<String> stdSet = new HashSet<String>();
		
		stdSet.add("Sunny");

		stdSet.add("Manu");

		stdSet.add("Albin");
		
		stdSet.add("Sunny");
		
		
		for(String name: stdSet )
		{
			
			System.out.println("Student Name:"+ name);
		}		

	}

}
