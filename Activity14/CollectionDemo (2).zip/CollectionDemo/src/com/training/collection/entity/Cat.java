/**
 * Cat
 * 
 * Cat entity
 * 
 * 05-10-2020
 */
package com.training.collection.entity;

/*Cat class */
public class Cat implements Comparable<Cat>{
	private String catName;
	private int catAge;
	
	public Cat(String catName, int catAge) {
		super();
		this.catName = catName;
		this.catAge = catAge;
	}
	
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public int getCatAge() {
		return catAge;
	}
	public void setCatAge(int catAge) {
		this.catAge = catAge;
	}

	@Override
	public String toString() {
		return "Cat: Name=" + catName + ", Age=" + catAge;
	}

	/**sorting by age*/
	@Override
	public int compareTo(Cat o) {
		return catAge-o.catAge;}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + catAge;
		result = prime * result + ((catName == null) ? 0 : catName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cat other = (Cat) obj;
		if (catAge != other.catAge)
			return false;
		if (catName == null) {
			if (other.catName != null)
				return false;
		} else if (!catName.equals(other.catName))
			return false;
		return true;
	}


	

}
