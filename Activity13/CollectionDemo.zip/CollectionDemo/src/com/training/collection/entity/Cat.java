/**
 * Cat
 * 
 * Cat entity
 * 
 * 05-10-2020
 */
package com.training.collection.entity;

/*Cat class */
public class Cat implements Comparable<Cat>{
	private String catName;
	private int catAge;
	
	public Cat(String catName, int catAge) {
		super();
		this.catName = catName;
		this.catAge = catAge;
	}
	
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public int getCatAge() {
		return catAge;
	}
	public void setCatAge(int catAge) {
		this.catAge = catAge;
	}

	@Override
	public String toString() {
		return "Cat: Name=" + catName + ", Age=" + catAge;
	}

	/**sorting by age*/
	@Override
	public int compareTo(Cat o) {
		return catAge-o.catAge;}


	

}
