/**
 * StudentService
 * 
 * ArrayList Implementation
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentService {

	public static void main(String[] args) {
	
		List<String> stdList = new ArrayList<String>();
		
		stdList.add("Sunny");

		stdList.add("Manu");

		stdList.add("Albin");
		
		
        System.out.println("Before Sorting\n");
		
		for(String name: stdList )
		{
			
			System.out.println("Student Name:"+ name);
		}

		System.out.println("\nAfter Sorting\n");
		
		
		Collections.sort(stdList);
		
		for(String name: stdList )
		{
			
			System.out.println("Student Name:"+ name);
		}
		
		

	}

}
