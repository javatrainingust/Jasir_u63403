/**
 * CatService
 * 
 * ArrayList Implementation for Cat
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.training.collection.entity.Cat;

public class CatService {

	public static void main(String[] args) {
		
		ArrayList<Cat> catList = new ArrayList<Cat>();
		
		Cat cat1 = new Cat("Lilly", 1);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("Mainkutty", 2);

		catList.add(cat1);
		catList.add(cat2);
		catList.add(cat3);
		
		System.out.println("befor sorting\n");
		Iterator<Cat> iterator = catList.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("\nafter sorting\n");
		Collections.sort(catList);
		Iterator<Cat> iterator1 = catList.iterator();
		while(iterator1.hasNext()) {
			System.out.println(iterator1.next());
		}
		}
	

}
