/***
 * ClassName:CurrentAccountController
 * 
 * Description:Class for getting all the current account details
 * 
 * Date-15-10-2020
 */

package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.service.CurrentAccountService;



@Controller
public class CurrentAccountController {

	
	/*CurrentAccount service class object is created using autowired annotation*/
	
	@Autowired
	private CurrentAccountService  currentAccountService;

	/***
	 * url /ShowCurrentForm mapped to this method 

	 */
	
	
	@RequestMapping("/showCurrentForm")
	public String showCurrentAccount(Model model)
	{
	CurrentAccount currentAccount = new CurrentAccount();
		model.addAttribute("caKey",currentAccount);
		return "addCurrentAccount";
	}
	
	
	/***
	 *
	 *  mapping /addCurrent url to this method in this
	 *  
	 *  calling service class method add also passing parameter
	 *  
	 *  current account and redirection the control
 	 * 
 	 * @param 
	 *
	 * @return CurrentAccount
	 */
	
	@RequestMapping("/addCurrent")
	public String addCurrent(@ModelAttribute("CurrenAccount") CurrentAccount currentAccount)
	{
 currentAccountService.addCurrentAccount(currentAccount);
	
		
		return "redirect:/CurrentAccount" ;
	}
	

	/***
	 * Url ending with /CurrentAccount mapped to get all deposite method
	 * 
	 * @param model
	 * @return currentDepositeList page in view
	 * getting all the current account and adding to model 
	 */
		
	
	
	
	
	@RequestMapping("/CurrentAccount")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallCurrentAccounts");
	
		List<CurrentAccount> currentDepositeList =currentAccountService.getAllCurAccounts();	
		
		model.addAttribute("currentList",currentDepositeList);
		
		return "currentDepositeList";
	}
/***
 * Method for getting the details of Current account by account number and assignig
 */
	@RequestMapping("/viewCurrentAccount")
	public String getCurrentAccount(@RequestParam("id")String id,Model model)
	
	{
		CurrentAccount currentAccount = currentAccountService.getCurAccountByAccountNum(Integer.parseInt(id));
		
		model.addAttribute("currentAccount",currentAccount);
		
		return "viewCurrentAccount";
	}
	/***
	 * Method for getting the details of Current account by account number and delete
	 */
		@RequestMapping("/deleteCurrentAccount")
		public String deleteCurrentAccount(@RequestParam("id")String id,Model model)
		
		{
			 currentAccountService.deleteCurAccount(Integer.parseInt(id));
			
			
			return "redirect:/CurrentAccount";
		}

	
		
		/***
		 * url /updateCurrentAccount Mapped to this method 
		 * 
		 * this method call updateExistingCurrentAccount using
		 */

		@RequestMapping("/updateCurrentAccount")
		public String updateCurrentAccount(@ModelAttribute("CurrenAccount") CurrentAccount currentAccount)
		{
			currentAccountService.updateCurrentAccount(currentAccount);
			return "redirect:/CurrentAccount" ;
		}
		
		/***
		 *  /sortcurrent AccounByName url maps to this method
		 */
		
		
		@RequestMapping("/sortCurrentAccountByName")
		public String  sortCurrentAccountByName(Model model)
		{
			List<CurrentAccount> currentAccounts = currentAccountService.getAllCurrentAccountsSortedByNames();
			
			model.addAttribute("currentList",currentAccounts);
			
			return "currentDepositeList";
		}
		
		/***
		 *  /sortcurrentAccounByOverdraft url maps to this method
		 * 
		 *  this method gets  sorted currentlist by name 
		 * 
		 * @param model - store currentlist in model
		 * 
		 * @return currentDepositeList
		 */
		
		
		
		
		@RequestMapping("/sortCurrentAccountByOverDraft")
		public String  sortCurrentAccountByBalance(Model model)
		{
			List<CurrentAccount> currentAccounts = currentAccountService.getAllCurrentAccountsSortedByBalance();
			
			model.addAttribute("currentList",currentAccounts);
			
			return "currentDepositeList";
		}
	
	
}
