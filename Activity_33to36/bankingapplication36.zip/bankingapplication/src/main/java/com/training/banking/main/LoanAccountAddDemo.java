package com.training.banking.main;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.LoanAccount;
import com.training.banking.service.CurrentAccountService;
import com.training.banking.service.LoanAccountService;

public class LoanAccountAddDemo {

	public static void main(String[] args) {
		
		LoanAccountService service = new LoanAccountService();
		
		service.addLoanAccount(new LoanAccount(123456720, "Jaleel", 45000.15f, "Educational", 2, 100000.0f));
		service.addLoanAccount(new LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f));
		service.addLoanAccount(new LoanAccount(123456722, "Ashker", 25000.15f, "Car", 4, 500000.0f));
		service.addLoanAccount(new LoanAccount(123456722, "Ashker", 25000.15f, "Car", 4, 500000.0f));
		service.addLoanAccount(new LoanAccount(123456720, "Jaleel kv ", 47000.15f, "Educational", 3, 100000.0f));

		System.out.println("Printing all LoanAccounts");	
		service.getAllLoanAccounts();
		System.out.println("---------------------------------------------");	
		service.updateLoanAccount(new LoanAccount(123456722, "Ashker ali", 25000.15f, "Car", 4, 500000.0f));
		
		System.out.println("Printing all updated LoanAccounts");	
		
		service.getAllLoanAccounts();

	}

}
