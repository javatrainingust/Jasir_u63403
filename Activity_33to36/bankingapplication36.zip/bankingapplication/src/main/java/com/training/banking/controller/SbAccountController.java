/***
 * ClassName:SbAccountController
 * 
 * Description:Class for getting all the savings bank details
 * 
 * Date-15-10-2020
 */
package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.banking.entity.SBAccount;
import com.training.banking.service.SBAccountservice;


/***
 * 
 * Class annotated with controller spring create SbAccountController class
 * 
 */
@Controller
public class SbAccountController {
	/*SavingsBank service class object is created using autowired annotation*/
	@Autowired
	private SBAccountservice savingsBankService;

	/***
	 * url/showsavingmethod mapped to this method 
	 */
	
	
	@RequestMapping("/showSavingsForm")
	public String showSavings(Model model)
	{
	SBAccount  sbAccount = new SBAccount();
		model.addAttribute("savingsKey",sbAccount);
		return "addSavingsAccount";
	}
	
	/***
	 *url /addSavings  is mapped to this method 
	 * 
	 */
	@RequestMapping("/addSavings")
	public String addSavings(@ModelAttribute("SavingAccount") SBAccount sbAccount)
	{
		savingsBankService.addSavingsAccount(sbAccount);;
	
		
		return "redirect:/Saving" ;
	}
	

	/***
	 * Url ending with /Saving mapped to get all deposite method
	 * 
	 */	
	@RequestMapping("/Saving")
	public String getAllDeposite(Model model)
	{
		
		System.out.println("Inside the controller getallSavings account");
	
		List<SBAccount> savingDepositeList =savingsBankService.getAllSBAccounts();	
		
		model.addAttribute("sbList",savingDepositeList);
		
		return "sbDepositeList";
	}

/***
* Method for getting the details of an Savings account by account number and assignig
*/


	@RequestMapping("/viewSbAccount")
	public String getSbAccount(@RequestParam("id")String id,Model model)
	{
		SBAccount sb =savingsBankService.getSBAccountByAccountNum(Integer.parseInt(id));
		
		model.addAttribute("savingsAccount",sb);
		
		return "viewSavingsAccount";
	}

	/***
	* Method for getting the details of an Savings account by account number and deleting it
	*/


		@RequestMapping("/deleteSbAccount")
		public String deleteSbAccount(@RequestParam("id")String id,Model model)
		{
			savingsBankService.deleteSBAccount(Integer.parseInt(id));
			
			
			return "redirect:/Saving";
		}
		
		/***
		 * url /updateSavingAccount Mapped to this method 
		 * @return /Saving
		 */
	
		@RequestMapping("/updateSavingsAccount")
		public String updateSavings(@ModelAttribute("SavingAccount") SBAccount sbAccount)
		{
			savingsBankService.updateSavingsAccount(sbAccount);
		
			
			return "redirect:/Saving" ;
		}
		
		/***
		 *  /sortSbAccounByName url maps to this method
		 */
		
		
		
		@RequestMapping("/sortSbAccountByName")
		public String  sortSavingsAccountByName(Model model)
		{
			List<SBAccount> sbAccounts = savingsBankService.getAllSavingsAccountsSortedByNames();
			
			model.addAttribute("sbList",sbAccounts);
			
			return "sbDepositeList";
		}
	
		/***
		 *  /sortSbAccounByBalance url maps to this method
		 */
		
		
		
		
		@RequestMapping("/sortSbAccountByBalance")
		public String  sortSavingsAccountByBalance(Model model)
		{
			List<SBAccount> sbAccounts = savingsBankService.getAllSavingsAccountsSortedByBalance();
			
			model.addAttribute("sbList",sbAccounts);
			
			return "sbDepositeList";
		}
}
