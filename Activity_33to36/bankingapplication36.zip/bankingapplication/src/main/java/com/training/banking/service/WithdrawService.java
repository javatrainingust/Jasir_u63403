/**
 * 
 */
package com.training.banking.service;

import com.training.banking.entity.SBAccount;
import com.training.banking.exception.InsufficiantMoneyException;
/**
 * 
 * @author Jasir
 *
 */
public class WithdrawService {

	public static void main(String[] args) {
		
		SBAccount sbAc = new SBAccount(123456789, "Rahim", 10000.0f);
		
		try {
			sbAc.withdrawMoney(15000.0f);
		} catch (InsufficiantMoneyException e) {
			
			System.out.println("Dear cutomer, " +e);
		}
		
		
	}

}
