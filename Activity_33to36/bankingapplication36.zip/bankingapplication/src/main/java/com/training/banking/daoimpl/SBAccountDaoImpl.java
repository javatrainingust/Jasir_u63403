/**
 * SBAccountDaoImpl
 * 
 * Implementation for SBAccount DAO operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.repository.SBAccountDAo;

/**
 * Implementation for SBAccount DAO
*/
@Repository
public class SBAccountDaoImpl implements SBAccountDAo {

	List sbAccountList;
	private Set sbAccountSet;
	/**
	 * Constructor for SBAccount DAO
	*/
	public SBAccountDaoImpl() {
		
		sbAccountList = new ArrayList<SBAccount>();
		sbAccountSet = new HashSet<SBAccount>();
		
		  SBAccount account1 = new SBAccount(123456710, "Ebin Varghese", 201001.0f);
		  SBAccount account2 = new SBAccount(123456711, "Allan k", 251001.0f);
		  SBAccount account3 = new SBAccount(123456712, "Vidhya ", 101001.0f);
		  SBAccount account4 = new SBAccount(123456713, "Ashley", 231001.0f);
		  
		  sbAccountList.add(account1); sbAccountList.add(account2);
		  sbAccountList.add(account3);
		 	sbAccountList.add(account4);
	}
	
	/**
	 * Implementation for get SBAccounts
	*/
	@Override
	public List<SBAccount> getAllSavingsAccounts() {
		return sbAccountList;
	}

	/**
	 * Implementation for get one SBAccounts by account numbers
	*/
	@Override
	public SBAccount getSBAccountByAccountNum(int acNumber) {
		SBAccount sbAccount =null;
		
		Iterator<SBAccount>   iterator = sbAccountList.iterator();
		
		while(iterator.hasNext()){
			
			SBAccount sb = iterator.next();
			
			if(sb.getAccountNumber()==acNumber){
				
				sbAccount=sb;
				
			}
				
		}

		return sbAccount;
	}

	/**
	 * Implementation for delete a SBAccounts by account numbers
	*/
	@Override
	public void deleteSavingsAccount(int acNumber) {
		
		for(int i=0; i< sbAccountList.size(); i++){
			
			SBAccount sb =(SBAccount)sbAccountList.get(i);
			
			if(sb.getAccountNumber()==acNumber){
				
				sbAccountList.remove(i);
				
			}
			
		}

	}
	/**
	 *  method for add Savings account to SET to avoid duplication and then add to List 
	 */
	@Override
	public boolean addSavingsAccount(SBAccount sbAccount) {
		boolean isAdded = sbAccountSet.add(sbAccount);
		if(isAdded) {
			sbAccountList.add(sbAccount);
		}
		return isAdded;
	}
	/**
	 * update savings account
	 */
	@Override
	public void updateSavingsAccount(SBAccount sbAccount) {
		Iterator iterator = sbAccountList.iterator();
		
		while(iterator.hasNext()){
			
			SBAccount la =(SBAccount)iterator.next();
			
			if(la.getAccountNumber()==sbAccount.getAccountNumber()){
				
			la.setAccountHolderName(sbAccount.getAccountHolderName());
			la.setAccountNumber(sbAccount.getAccountNumber());
			la.setAccountBalance(sbAccount.getAccountBalance());
			}
		
		}
		
	}
}
