/**
 * LoanAccount
 * 
 * Entity class for handle the loan account
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

/**
 * Sub class derived from account call to handle loan accounts 
 */
public class LoanAccount extends Account implements Comparable<LoanAccount>{
	
	private String loanType;
	private int tenure;
	private float loanAmount;
	private float emi;
	private float intrest = 13;
	
	/**
	 * constructor for loan account
	 */
	public LoanAccount(int accountNumber, String accountHolderName, float accountBalance, String loanType, int tenure,
			float loanAmount) {
		super(accountNumber, accountHolderName, accountBalance);
		this.loanType = loanType;
		this.tenure = tenure;
		this.loanAmount = loanAmount;
	}

	/**
	 * get the type of loan
	 */
	public String getLoanType() {
		return loanType;
	}
	
	/**
	 * set the type of loan
	 */
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	
	/**
	 * get the time period of loan
	 */
	public int getTenure() {
		return tenure;
	}
	
	/**
	 * set the time period of loan
	 */
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	/**
	 * get the loan amount
	 */
	public float getLoanAmount() {
		return loanAmount;
	}
	
	/**
	 * set loan amount
	 */
	public void setLoanAmount(float loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	/**
	 * get the emi
	 */
	public float getEmi() {
		return emi;
	}
	
	/**
	 * calculate emi
	 */
	public void calculate_emi() {
		float emi_;
		float p= this.loanAmount;
		int n=this.tenure;
		
		
	/*just_simple_claculation*/
		emi_ = p/n;
		
		this.emi = emi_;
		
	}
	/**
	 * Comparable implementation for sorting
	*/
	@Override
	public int compareTo(LoanAccount o) {
		
		return this.getAccountHolderName().compareTo(o.getAccountHolderName());
	}

}
