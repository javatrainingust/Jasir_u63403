package com.junit.test.service;

public class Calculator {

	public float substract(int a,int b) {
		
		return a-b;
	}
}
