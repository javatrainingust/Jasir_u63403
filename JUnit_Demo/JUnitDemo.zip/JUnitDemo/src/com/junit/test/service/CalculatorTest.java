package com.junit.test.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testSubstract() {
		
		float expected_value = 2;
		Calculator cal = new Calculator();
		float actual_value = cal.substract(5, 3);
		assertEquals(expected_value, actual_value);
	}

}
