/***
 * ClassName:loanAccountController
 * 
 * Description:Class for getting all the savings bank details
 * 
 * Date-22-10-2020
 */
package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.service.LoanAccountService;
import com.training.banking.service.SBAccountservice;

/**
 * API Request response controller
 * 
 * @author Jasir
 *
 */
@RestController
@RequestMapping("/loan")
public class LoanAccountController {
	/* loan service class object is created using autowired annotation */
	@Autowired
	private LoanAccountService loanBankService;

	/***
	 * URL mapping for add accounts
	 */
	@RequestMapping(value = "/accounts", method = RequestMethod.POST)
	public String addSavings(@RequestBody LoanAccount laonAccount) {
		loanBankService.addLoanAccount(laonAccount);
		return "Success";
	}

	/***
	 * URL mapping for get all accounts
	 */
	@RequestMapping(value = "/accounts", method = RequestMethod.GET)
	public List<LoanAccount> getAllDeposite() {

		System.out.println("Inside the controller getallSavings account");

		List<LoanAccount> loanList = loanBankService.getAllLoanAccounts();

		return loanList;
	}

	/**
	 * URL mapping for get one account
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.GET)
	public LoanAccount getSbAccount(@PathVariable int id) {
		LoanAccount la = loanBankService.getLoanAccountByAccountNum(id);
		return la;
	}

	/**
	 * URL mapping for delete one account
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.DELETE)
	public String deleteSbAccount(@PathVariable int id) {
		loanBankService.deleteLoanAccount(id);

		return "Successfully deleted";
	}

	/**
	 * URL mapping for update an accounts
	 * 
	 * @param id
	 * @param sbAccount
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.PUT)
	public String updateSavings(@PathVariable int id, @RequestBody LoanAccount sbAccount) {
		LoanAccount isTrue = loanBankService.getLoanAccountByAccountNum(id);
		if (isTrue != null) {
			loanBankService.updateLoanAccount(sbAccount);
		}
		return "Updated Successfully";
	}

	/**
	 * URL mapping for get all accounts in sorted by names
	 * 
	 * @return
	 */
	@RequestMapping(value = "/accounts/names", method = RequestMethod.GET)
	public List<LoanAccount> sortSavingsAccountByName() {
		List<LoanAccount> loanAccounts = loanBankService.getAllLoanAccountsSortedByNames();
		return loanAccounts;

	}

	/**
	 * URL mapping for get all accounts in sorted by balance
	 * 
	 * @return
	 */
	@RequestMapping(value = "/accounts/balance", method = RequestMethod.GET)
	public List<LoanAccount> sortSavingsAccountByBalance() {
		List<LoanAccount> loanAccounts = loanBankService.getAllLoanAccountsSortedByBalance();
		return loanAccounts;

	}
}
