/**
 * AccountRenew
 * 
 * Interface for renew. reduce the dependency
 *
 * 28/09/2020
 * 
*/
package com.training.banking.interfaces;
/**
 * Interface for renew the account
 */
public interface AccountRenew {
	
	public void autoRenew(int tenure);

}
