package com.training.banking.testcase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.banking.daoimpl.CurrentAaccountDaoImpl;
import com.training.banking.daoimpl.LoanAccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.LoanAccount;
import com.training.banking.service.LoanAccountService;

class LoanAccountServiceTest {
	List loanAccountListTest;
	LoanAccountService service;
	public LoanAccountServiceTest() {
		loanAccountListTest = new ArrayList<LoanAccount>();
		service = new LoanAccountService();
		
		service.addLoanAccount(new LoanAccount(123456720, "Jaleel", 45000.15f, "Educational", 2, 100000.0f));
		service.addLoanAccount(new LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f));
		service.addLoanAccount(new LoanAccount(123456722, "Ashker", 25000.15f, "Car", 4, 500000.0f));
		service.addLoanAccount(new LoanAccount(123456722, "Ashker", 25000.15f, "Car", 4, 500000.0f));
		service.addLoanAccount(new LoanAccount(123456720, "Jaleel kv ", 47000.15f, "Educational", 3, 100000.0f));

		loanAccountListTest = service.getAllLoanAccounts();
	}
	@Test
	void testaddLoanAccount() {
		LoanAccountDaoImpl daoImpl = new LoanAccountDaoImpl();
		boolean actualTrueValue = daoImpl.addLoanAccount(new LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f));
		boolean actualFalseValue = daoImpl.addLoanAccount(new LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f));
		assertTrue(actualTrueValue);
		assertFalse(actualFalseValue);
	}
	@Test
	void testGetAllLoanAccounts() {
		List<LoanAccount> actualList = new ArrayList<LoanAccount>();
		actualList = service.getAllLoanAccounts();
		assertEquals(actualList.size(), loanAccountListTest.size());
	}

	@Test
	void testGetLaonAccountByAccountNum() {
		String expectedValue = "Ashker";
		LoanAccount actualValue = service.getLoanAccountByAccountNum(123456722);
		assertEquals(expectedValue,actualValue.getAccountHolderName());
	}

	@Test
	void testDeleteLaonAccount() {
		int expectedSize =3;
		List<LoanAccount> actualList = new ArrayList<LoanAccount>();
		service.deleteLoanAccount(123456723);
		actualList = service.getAllLoanAccounts();
		assertEquals(expectedSize, actualList.size());
	}

	@Test
	void testGetAllLoanAccountsSortedByNames() {
		String expectedValue = "Ashker";
		List<LoanAccount> loanAccount = service.getAllLoanAccountsSortedByNames();
		String actualValue = loanAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllLoanAccountsSortedByBalance() {
		float expectedValue = 25000.15f;
		List<LoanAccount> loanAccount = service.getAllLoanAccountsSortedByNames();
		float actualValue = loanAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
