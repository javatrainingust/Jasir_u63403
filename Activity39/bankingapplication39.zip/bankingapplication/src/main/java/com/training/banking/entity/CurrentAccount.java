/**
 * InterestCalculator
 * 
 * Entity class for handle the current account account
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

/**
 * sub class for current account derived from account class 
*/
public class CurrentAccount extends Account implements Comparable<CurrentAccount>{

	private float overDraftLimit;
	
	/**
	 * Constructor for Current Account
	*/
	public CurrentAccount(int accountNumber, String accountHolderName, float accountBalance, float overDraftLimit) {
		super(accountNumber, accountHolderName, accountBalance);
		this.overDraftLimit = overDraftLimit;
	}

	public CurrentAccount() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * get the limit of over draft
	*/
	public float getOverDraftLimit() {
		return overDraftLimit;
	}
	
	/**
	 * Set the limit of over draft
	*/
	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}

	/**
	 * Comparable implementation for sorting
	*/
	@Override
	public int compareTo(CurrentAccount o) {
		
		return this.getAccountHolderName().compareTo(o.getAccountHolderName());
	}
	
	
}
