/***
 * ClassName:savingsAccountController
 * 
 * Description:Class for getting all the savings bank details
 * 
 * Date-22-10-2020
 */
package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.service.LoanAccountService;
import com.training.banking.service.SBAccountservice;

/**
 * API Request response controller
 * 
 * @author Jasir
 *
 */
@RestController
@RequestMapping("/savings")
public class SbAccountController {

	/* SavingsBank service class object is created using autowired annotation */
	@Autowired
	private SBAccountservice savingsBankService;

	/***
	 * URL mapping for add accounts
	 */
	@RequestMapping(value = "/accounts", method = RequestMethod.POST)
	public String addSavings(@RequestBody SBAccount sbAccount) {
		savingsBankService.addSavingsAccount(sbAccount);
		return "Success";
	}

	/***
	 * URL mapping for get all accounts
	 */
	@RequestMapping(value = "/accounts", method = RequestMethod.GET)
	public List<SBAccount> getAllDeposite() {

		System.out.println("Inside the controller getallSavings account");

		List<SBAccount> savingDepositeList = savingsBankService.getAllSBAccounts();

		return savingDepositeList;
	}

	/**
	 * URL mapping for get one account
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.GET)
	public SBAccount getSbAccount(@PathVariable int id) {
		SBAccount sb = savingsBankService.getSBAccountByAccountNum(id);
		return sb;
	}

	/**
	 * URL mapping for delete one account
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.DELETE)
	public String deleteSbAccount(@PathVariable int id) {
		savingsBankService.deleteSBAccount(id);

		return "Successfully deleted";
	}

	/**
	 * URL mapping for update an accounts
	 * 
	 * @param id
	 * @param sbAccount
	 * @return
	 */
	@RequestMapping(value = "/accounts/{id}", method = RequestMethod.PUT)
	public String updateSavings(@PathVariable int id, @RequestBody SBAccount sbAccount) {
		SBAccount isTrue = savingsBankService.getSBAccountByAccountNum(id);
		if (isTrue != null) {
			savingsBankService.updateSavingsAccount(sbAccount);
		}
		return "Updated Successfully";
	}

	/**
	 * URL mapping for get all accounts in sorted by names
	 * 
	 * @return
	 */
	@RequestMapping(value = "/accounts/names", method = RequestMethod.GET)
	public List<SBAccount> sortSavingsAccountByName() {
		List<SBAccount> sbAccounts = savingsBankService.getAllSavingsAccountsSortedByNames();
		return sbAccounts;

	}

	/**
	 * URL mapping for get all accounts in sorted by balance
	 * 
	 * @return
	 */
	@RequestMapping(value = "/accounts/balance", method = RequestMethod.GET)
	public List<SBAccount> sortSavingsAccountByBalance() {
		List<SBAccount> sbAccounts = savingsBankService.getAllSavingsAccountsSortedByBalance();
		return sbAccounts;

	}
}
