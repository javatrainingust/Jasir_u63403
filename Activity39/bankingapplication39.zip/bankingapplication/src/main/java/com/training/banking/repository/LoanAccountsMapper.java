/**
 * LoanAccountsMapper
 * 
 * row mapper implementation for loan accounts
 * 
 * 23/10/2020
 */
package com.training.banking.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
/**
 * rowmapper implementation
 * @author Jasir
 *
 */
public class LoanAccountsMapper implements RowMapper<LoanAccount> {
	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		LoanAccount loanAc =  new LoanAccount();
		
		loanAc.setAccountBalance(rs.getInt("balance"));
		
		loanAc.setAccountHolderName(rs.getString("name"));
		
		loanAc.setAccountNumber(rs.getInt("accountNumber"));
		
		loanAc.setLoanAmount(rs.getFloat("amount"));
		
		loanAc.setLoanType(rs.getString("type"));
		
		loanAc.setTenure(rs.getInt("tenure"));
		
		return loanAc;
}}
