/**
 * FuntionalIntefaceDemo1
 * Demo for Supplier interface
 * 08/10/2020
 */
package com.training.funtionalInterface.demo;

import java.util.Random;
import java.util.function.Supplier;
/**
 * 
 * @author Jasir
 * Built in functional interface supplier demo
 */
public class FuntionalIntefaceDemo1 {

	public static void main(String[] args) {
		/* this will return random ineteger each time*/
		Random rand = new Random(); 
		Supplier getRandomNum = ()->rand.nextInt(1000);
		System.out.println(getRandomNum.get());
		
	}

}
