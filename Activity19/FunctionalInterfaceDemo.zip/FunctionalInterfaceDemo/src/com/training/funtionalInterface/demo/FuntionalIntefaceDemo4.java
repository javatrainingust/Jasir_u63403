/**
 * FuntionalIntefaceDemo4
 * Function interface implementation
 */
package com.training.funtionalInterface.demo;

import java.util.function.Function;

/**
 * 
 * @author Jasir
 * Function interface demo
 */
public class FuntionalIntefaceDemo4 {

	/* it will return upper case value of given string */
	public static void main(String[] args) {

		Function<String, String> convertor = (s) -> {
		      
			 return s.toUpperCase();
			
		};
		
		System.out.println("Uppercase : "+convertor.apply("convert"));
	}

	

}
