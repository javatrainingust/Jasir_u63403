/**
 * FuntionalIntefaceDemo2
 * implementation of Consumer interface
 * 08/10/2020
 */
package com.training.funtionalInterface.demo;

import java.util.function.Consumer;
/**
 * 
 * @author Jasir
 * Consumer interface demo
 */
public class FuntionalIntefaceDemo2 {

	/*it will print uppercase letter of given string input*/
	public static void main(String[] args) {
		Consumer<String> convertToUpper =(s)-> System.out.println(s.toUpperCase());

		convertToUpper.accept("jasir");
	}

}
