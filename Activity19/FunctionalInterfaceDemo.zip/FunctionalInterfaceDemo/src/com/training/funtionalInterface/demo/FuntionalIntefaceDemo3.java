/**
 * FuntionalIntefaceDemo3
 * Predicate interface implementation
 * 08/10/2020
 */
package com.training.funtionalInterface.demo;

import java.util.function.Predicate;
/**
 * 
 * @author Jasir
 * functional interface predicate
 */
public class FuntionalIntefaceDemo3 {

	/* it will return true if the number is gratre than 50,otherwise false */
	public static void main(String[] args) {
		Predicate <Integer> isGrater = (i) -> {
		      
			 if(i>50) {
				 
				 return true;
				 
			 }
			 else {
				 
				 return false;
			 }
			
		};
		
		System.out.println("given number is grater than 50? "+isGrater.test(20));

	}

}
