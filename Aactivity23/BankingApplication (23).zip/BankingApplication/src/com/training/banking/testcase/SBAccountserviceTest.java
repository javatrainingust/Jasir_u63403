package com.training.banking.testcase;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.daoimpl.LoanAccountDaoImpl;
import com.training.banking.daoimpl.SBAccountDaoImpl;
import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.service.SBAccountservice;

class SBAccountserviceTest {
	List sbAccountListTest;
	SBAccountservice service;
	public SBAccountserviceTest() {
		
		sbAccountListTest = new ArrayList<SBAccount>();
		service = new SBAccountservice();
		service.addSavingsAccount(new SBAccount(123456710, "Ebin Varghese", 201001.0f));
		service.addSavingsAccount(new SBAccount(123456711, "Allan k", 251001.0f));
		service.addSavingsAccount(new SBAccount(123456712, "Vidhya ", 101001.0f));
		service.addSavingsAccount(new SBAccount(123456713, "Ashley", 231001.0f));
		service.addSavingsAccount(new SBAccount(123456710, "Ebin", 20101.0f));
		
		sbAccountListTest = service.getAllSBAccounts();
	}
	
	@Test
	void testaddSavingsAccount() {
		SBAccountDaoImpl daoImpl = new SBAccountDaoImpl();
		boolean actualTrueValue = daoImpl.addSavingsAccount(new SBAccount(123456710, "Ebin Varghese", 201001.0f));
		boolean actualFalseValue = daoImpl.addSavingsAccount(new SBAccount(123456710, "Ebin Varghese", 201001.0f));
		assertTrue(actualTrueValue);
		assertFalse(actualFalseValue);
	}
	@Test
	void testGetAllSavingsAccounts() {
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		actualList = service.getAllSBAccounts();
		assertEquals(actualList.size(), sbAccountListTest.size());
	}

	@Test
	void testGetSBAccountByAccountNum() {
		String expectedValue = "Allan k";
		SBAccount actualValue = service.getSBAccountByAccountNum(123456711);
		System.out.println( actualValue.getAccountHolderName());
		assertEquals(expectedValue, actualValue.getAccountHolderName());
	}

	@Test
	void testDeleteSavingsAccount() {
		int expectedSize = 3;
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		service.deleteSBAccount(123456713);
		actualList = service.getAllSBAccounts();
		assertEquals(expectedSize, actualList.size());
	}
	@Test
	void testGetAllSavingsAccountsSortedByNames() {
		String expectedValue = "Allan k";
		List<SBAccount> savingsAccount = service.getAllSavingsAccountsSortedByNames();
		String actualValue = savingsAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllSavingsAccountsSortedByBalance() {
		float expectedValue = 101001.0f;
		List<SBAccount> savingsAccount = service.getAllSavingsAccountsSortedByBalance();
		float actualValue = savingsAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
