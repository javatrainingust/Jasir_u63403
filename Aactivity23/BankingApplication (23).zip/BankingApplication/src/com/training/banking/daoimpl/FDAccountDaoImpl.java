/**
 * FDAccountDaoImpl
 * 
 * Implementation for FDAccount dao operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.banking.entity.FDAccount;
import com.training.banking.repository.FDAccountDao;

/**
 * Implementation for FDAccount DAO
*/
public class FDAccountDaoImpl implements FDAccountDao {

	List fdAccountList;
	private Set fixedAccountSet; 
	/**
	 * Constructor for FDAccount DAO
	*/
	public FDAccountDaoImpl() {
		fdAccountList = new ArrayList<FDAccount>();
		fixedAccountSet = new HashSet<FDAccount>();
		
		  FDAccount account1 = new FDAccount(123456789, "Albin Jose", 10000.0f, 2,
		  true, 2022); FDAccount account2 = new FDAccount(123456790, "Manohar k k",
		  15000.0f, 1, true, 2021); FDAccount account3 = new FDAccount(123456791,
		  "Raguvaran", 20000.0f, 3, true, 2023); FDAccount account4 = new
		  FDAccount(123456792, "Bunny P", 18000.0f, 5, true, 2025);
		  
		  fdAccountList.add(account1); fdAccountList.add(account2);
		  fdAccountList.add(account3); fdAccountList.add(account4);
		 
	}
	
	/**
	 * Implementation for get FDAccounts
	*/
	@Override
	public List<FDAccount> getAllFixedAccounts() {
		return fdAccountList;
	}

	/**
	 * Implementation for get one FDAccounts by account numbers
	*/
	@Override
	public FDAccount getFdAccountByAccountNum(int acNumber) {
		FDAccount fdAccount =null;
		
		Iterator<FDAccount>   iterator = fdAccountList.iterator();
		
		while(iterator.hasNext()){
			
			FDAccount fd = iterator.next();
			
			if(fd.getAccountNumber()==acNumber){
				
				fdAccount=fd;
				
			}
				
		}

		return fdAccount;
	}

	/**
	 * Implementation for delete a FDAccounts by account numbers
	*/
	@Override
	public void deleteFixedAccount(int acNumber) {
		
		for(int i=0; i< fdAccountList.size(); i++){
			
			FDAccount fd =(FDAccount)fdAccountList.get(i);
			
			if(fd.getAccountNumber()==acNumber){
				
				fdAccountList.remove(i);
				
			}
			
		}

	}
	
	/**
	 * method for add fixed account to SET to avoid duplication and then add to List 
	 */
	@Override
	public boolean addFixedAccount(FDAccount fdAccount) {
		boolean isAdded = fixedAccountSet.add(fdAccount);
		
		if(isAdded) {
			
			fdAccountList.add(fdAccount);
		}
		return isAdded;
	}
	
	/**
	 * Update the existing fixed account
	 */
	@Override
	public void updateFixedAccount(FDAccount fdAccount) {
		Iterator iterator = fdAccountList.iterator();
		
		
		while(iterator.hasNext()){
			
			FDAccount fd =(FDAccount)iterator.next();
			
			if(fd.getAccountNumber()==fdAccount.getAccountNumber()){
				
			fd.setAccountHolderName(fdAccount.getAccountHolderName());
			fd.setAccountNumber(fdAccount.getAccountNumber());
			fd.setAccountBalance(fdAccount.getAccountBalance());
				
			}
		}
		
	}

}
