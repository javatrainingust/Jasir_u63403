/**
 * CurrentAccountService
 * 
 * Business logics for Current Account 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.service;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.training.banking.daoimpl.CurrentAaccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.repository.CurrentAccountDao;
import com.training.banking.util.CurrentAccountComparator;

/**
 * Service class for Current account
*/
public class CurrentAccountService {

	CurrentAccountDao CurrentAccountDao;
	
	/**
	 * Constructor for Current account service
	*/
	public CurrentAccountService(){
			
		CurrentAccountDao = new CurrentAaccountDaoImpl();
			
		} 
	
	/**
	 * Fetch all Current Accounts
	 */
	public List<CurrentAccount> getAllCurAccounts() {
	
		List curentAccountList = CurrentAccountDao.getAllCurrentAccount();
		
		Iterator<CurrentAccount> iterator = curentAccountList.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount fd = iterator.next();
			
			System.out.println("Name = "+fd.getAccountHolderName());
			System.out.println("Account Number ="+fd.getAccountNumber());
			System.out.println("Account Balance = "+fd.getAccountBalance());
			
			}			

		return curentAccountList;
		
	}
		
	/**
	 * Fetch one Current account by its account number
	 */
	public CurrentAccount getCurAccountByAccountNum(int accountNumber) {
		
		CurrentAccount fd = CurrentAccountDao.getCurrentAccountByAccountNum(accountNumber);
				
		System.out.println("Name = "+fd.getAccountHolderName());
		System.out.println("Account Number ="+fd.getAccountNumber());
		System.out.println("Account Balance = "+fd.getAccountBalance());
		
		return fd;
		
	}
		
	/**
	 * Remove one Current account by its account number
	 */	
	public void deleteCurAccount(int accountNumber) {
		
		CurrentAccountDao.deleteCurrentAccount(accountNumber);
		
	}	
	/**
	 * Sort Accounts by account holder names using Stream
	 */
	
	public List<CurrentAccount>	getAllCurrentAccountsSortedByNames(){
		
		
		List<CurrentAccount> CurrentAccount = CurrentAccountDao.getAllCurrentAccount();
		
		//Collections.sort(CurrentAccount);
		
		Stream<CurrentAccount> currentAcStream = CurrentAccount.stream();
		
		Stream<CurrentAccount> sortedStream = currentAcStream.sorted();
		
		List sortedCurrentAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<CurrentAccount> iterator = sortedCurrentAccount.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount curAc = iterator.next();
			System.out.println("Name = "+curAc.getAccountHolderName());
			System.out.println("Account Number ="+curAc.getAccountNumber());
			System.out.println("Account Balance = "+curAc.getAccountBalance());			
			
			}			

		return CurrentAccount;
	}
	/**
	 * Sort Accounts by account balance using Stream
	 */
	
	public List<CurrentAccount>	getAllCurrentAccountsSortedByBalance(){
		
		
		List<CurrentAccount> CurrentAccount = CurrentAccountDao.getAllCurrentAccount();
		
//		Collections.sort(CurrentAccount, new CurrentAccountComparator() {
//		});
//		
		
		Stream<CurrentAccount> currentAcStream = CurrentAccount.stream();
		
		Stream<CurrentAccount> sortedStream = currentAcStream.sorted(new CurrentAccountComparator());
		
		List sortedCurrentAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<CurrentAccount> iterator = sortedCurrentAccount.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount curAc = iterator.next();
			System.out.println("Name = "+curAc.getAccountHolderName());
			System.out.println("Account Number ="+curAc.getAccountNumber());
			System.out.println("Account Balance = "+curAc.getAccountBalance());			
			
			}			

		return CurrentAccount;
	}
	/**
	 * service for add current account
	 * @param curAccount
	 */
	public void addCurrentAccount(CurrentAccount curAccount) {
		
		boolean isAdded = CurrentAccountDao.addCurrentAccount(curAccount);
		
		if(!isAdded){
			
			System.out.println("The Current account already exist");
		}
		else{
			System.out.println("The Current account successfully added");
			
		}
	}
	/**
	 * service for update current account
	 * @param curAccount
	 */
	public void updateCurrentAccount(CurrentAccount curAccount){
		
		CurrentAccountDao.updateCurrentAccount(curAccount);
	}
	
	

}
