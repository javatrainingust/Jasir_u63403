package com.training.banking.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.banking.exception.InsufficiantMoneyException;

class AccountTest {

	@Test
	void testWithdrawMoney() throws InsufficiantMoneyException {
		
		float expectedValue = 8000;
		Account acount = new Account();
		acount.withdrawMoney(2000);
		float actualValue = acount.getAccountBalance();
		assertEquals(expectedValue, actualValue);
		
		
	}

}
