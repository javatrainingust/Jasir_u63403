package com.training.ioc.bean;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class OrganizerTest {

	@Test
	public void testSayGreetings() {

		
	}

}
