/**
 * SpringDemo
 * 
 * demo for Spring Inversion of control
 * 
 * 12/10/2020
 */
package com.training.ioc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.ioc.bean.Organizer;
import com.training.ioc.bean.SpringConfig;

/**
 * 
 * @author Jasir
 * IOC demo
 */
public class SpringDemo {

	public static void main(String[] args) {
		
		/* loading the definitions from java config */
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		 
		Organizer org =  context.getBean("competionOrganizer",Organizer.class);
		
		org.sayGreetings();

	}

}
