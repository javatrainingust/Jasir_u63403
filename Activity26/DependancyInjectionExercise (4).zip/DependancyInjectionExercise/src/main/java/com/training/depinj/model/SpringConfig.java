package com.training.depinj.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

	
	@Bean(name = "instrumentalistObj")
	public Instrumentalist getInstrumentalist() {
		System.out.println("Inside getInstrumentalist method in config");
		
		Instrumentalist instrObj = new Instrumentalist();
		
		instrObj.setSaxophon(getSaxophone());
		
		return instrObj;
		
	}
	@Bean
	public Saxophone getSaxophone() {
		
		System.out.println("Inside getSaxophone method in config");
		
		Saxophone saxophoneObj = new Saxophone();
		
		return saxophoneObj;
		
	}
	
}
