/**
 * Performer
 * Interface for performer
 * 12/10/2020
 */
package com.training.depinj.util;

/**
 * Interface for performer
 * @author Jasir
 *
 */
public interface Performer {

	public void perform();
}
