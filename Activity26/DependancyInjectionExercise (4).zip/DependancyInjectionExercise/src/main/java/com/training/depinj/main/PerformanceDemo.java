/**
 * PerformanceDemo
 * 
 * Dependency injection demo
 * 
 * 12/10/2020
 */
package com.training.depinj.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.depinj.model.Instrumentalist;
import com.training.depinj.model.SpringConfig;
/**
 * 
 * @author Jasir
 * Demo for Dependency injection through constructor
 */
public class PerformanceDemo {

	public static void main(String[] args) {
		
		/* loading the definitions from the given XML file */
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);

		
		Instrumentalist instrumentalist = context.getBean("instrumentalistObj", Instrumentalist.class);
		
		instrumentalist.perform();


	}

}
