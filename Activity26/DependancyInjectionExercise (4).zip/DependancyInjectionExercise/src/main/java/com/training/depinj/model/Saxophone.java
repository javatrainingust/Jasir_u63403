/**
 * Saxophone
 * 
 * Demo for dependency injection through setter method
 * 
 * 12/10/2020
 */
package com.training.depinj.model;

import org.springframework.stereotype.Component;

import com.training.depinj.util.Instrument;
/**
 * Demo for dependency injection through setter method
 * @author Jasir
 *
 */

public class Saxophone implements Instrument {

	/**
	 * implementation
	 */
	public void play() {
		
		System.out.println("Saxophone playing started..");
		
	}

}
