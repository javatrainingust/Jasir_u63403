/**
 * Guitar
 * 
 * Demo for dependency injection through setter method
 * 
 * 12/10/2020
 */
package com.training.depinj.model;

import com.training.depinj.util.Instrument;
/**
 * Demo for dependency injection through setter method
 * @author Jasir
 *
 */
public class Guitar implements Instrument {

	/**
	 * implementation
	 */
	public void play() {
		
		System.out.println("Guitar playing started..");
		
	}

}
