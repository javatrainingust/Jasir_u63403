/**
 * Flue
 * 
 * Demo for dependency injection through setter method
 * 
 * 12/10/2020
 */
package com.training.depinj.model;

import com.training.depinj.util.Instrument;
/**
 * Demo for dependency injection through setter method
 * @author Jasir
 *
 */
public class Flue implements Instrument {

	/**
	 * implementation
	 */
	public void play() {
		
		System.out.println("Flue playing started..");
		
	}

}
