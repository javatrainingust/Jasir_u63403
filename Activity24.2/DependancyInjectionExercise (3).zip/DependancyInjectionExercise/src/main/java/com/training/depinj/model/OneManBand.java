/**
 * OneManBand
 * 
 * example for Injecting Collection
 * 
 * 12/10/2020
 * 
 */
package com.training.depinj.model;

import java.util.Iterator;
import java.util.List;

import com.training.depinj.util.Instrument;
import com.training.depinj.util.Performer;

/**
 * example for Injecting Collection
 * @author Jasir
 *
 */
public class OneManBand implements Performer {

	public List<Instrument> instruments;
	
	/**
	 * Get instruments list
	 * @return
	 */
	public List<Instrument> getInstruments() {
		return instruments;
	}

	/**
	 * Set instrument list
	 * @param instruments
	 */
	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}

	/**
	 * implementation of perform
	 */
	public void perform() {
		
		Iterator iterator = instruments.iterator();
		
		while(iterator.hasNext()) {
			
			Instrument instrList = (Instrument) iterator.next();
			instrList.play();
		}
		
		
	}

}
