/**
 * InterestCalculator
 * 
 * Entity class for handle the Fixed deposit account
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.training.banking.interfaces.ICalculateInterest;

import com.training.banking.interfaces.AccountRenew;

/**sub class for FD account derived from account class that uses a interface for renew */
public class FDAccount extends Account implements AccountRenew {
	
	private int tenure ;
	private boolean autoRenewal = true;
	private float rate;
	private int maturity_date;
	
	/**Parameterized constructor*/
	public FDAccount(int tenure, float rate) {
		super();
		this.tenure = tenure;
		this.rate = rate;
		System.out.println("inside FDAccount arg costructor");
	}
	
	/**non-para constructor*/
	public FDAccount() {
		System.out.println("inside FDAccount non-arg costructor");
	}

	/**get the value of rate*/
	public float getRate() {
		return rate;
	}
	
	/**assign the value to rate*/
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	
	/**get the value of tenure*/
	public int getTenure() {
		return tenure;
	}
	
	/**assign the value to tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	/**get the renewal value*/
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	
	/**assign the value to renewal*/
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	/**overriding method for calculate interest*/
	public void calculateInterest(ICalculateInterest calcs) {
		
		float interesrt = calcs.calculateInterest(getAccountBalance(),rate,tenure);
		System.out.println("your FDAccount will have RS "+interesrt+ " as interest  with rate "+rate);
		
	}
	/**automatically renew when meet the maturity date*/
	@Override
	public void autoRenew(int tenure) {
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Calendar calobj = Calendar.getInstance();
		Calendar valid_date = Calendar.getInstance();
		valid_date.set(2020, 9, 1);
		/*check auto renewal is true*/ 
		System.out.println(this.autoRenewal);
		if(this.autoRenewal) {
			if (df.format(valid_date.getTime()).compareTo(df.format(calobj.getTime()))==0) {
				valid_date.add(Calendar.YEAR,tenure);
				this.maturity_date = valid_date.get(1);
				System.out.println("Your FD account got automatically renewed. new maturity date is "+getMaturity_date());
			}
		}
		
	}

	public int getMaturity_date() {
		return maturity_date;
	}
	

}
