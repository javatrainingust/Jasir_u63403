/**
 * CollectionService
 * 
 * HashMap Implementation
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.HashMap;
import java.util.Map;

public class CollectionService {

	public static void main(String[] args) {
	
		/**key-value pair*/
		Map<String,String> movies = new HashMap<String, String>();
		
		movies.put("Dulquer", "Ustad Hotel");

		movies.put("Mohanlal", "Thanmatra");
		
		movies.put("Mammootty", "Mathilukal");
		
		movies.put("Dileep", "Ramaleela");
		
		/**retrieve value by using key*/
		
		System.out.println("The film "+movies.get("Dulquer") + " Starred by Dulquer");	
		System.out.println("The film "+movies.get("Mohanlal") + " Starred by Mohanlal");
		System.out.println("The film "+movies.get("Mammootty") + " Starred by Mammootty");
		System.out.println("The film "+movies.get("Dileep") + " Starred by Dileep");

	}

}
