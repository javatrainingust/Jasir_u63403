/**
 * CatService
 * 
 * HashMap Implementation for Cat
 * 
 * 05-10-2020
 */
package com.training.collection.service;

import java.util.HashMap;
import java.util.Map;

import com.training.collection.entity.Cat;

public class CatService {

	public static void main(String[] args) {
		
		Map<Cat,String> catMap = new HashMap<Cat,String>();
		
		Cat cat1 = new Cat("Lilly", 1);
		Cat cat2 = new Cat("pinky", 3);
		Cat cat3 = new Cat("Manikutty", 2);

		catMap.put(cat1,"Leela");
		catMap.put(cat2,"Panikkar");
		catMap.put(cat3,"Mani");
		
		System.out.println("Lilly = "+catMap.get(new Cat("Lilly", 1)));
		System.out.println("pinky = "+catMap.get(new Cat("pinky", 3)));
		System.out.println("Manikutty = "+catMap.get(new Cat("", 2)));
		}
	

}
