package com.training.banking;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.banking.daoimpl.SBAccountSqlImpl;
import com.training.banking.entity.SBAccount;
import com.training.banking.service.SBAccountservice;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class BankingApplicationTests {
	@Mock
	private SBAccountSqlImpl sbaAccountDAOMock;
	
	@InjectMocks
	private SBAccountservice service;

	@Test 
	  public void testGetAllEmployeesBySalary() {
		
		SBAccount sb1 = new SBAccount();
		sb1.setAccountBalance(50000);
		
		SBAccount sb2 = new SBAccount();
		sb2.setAccountBalance(40000);
		
		SBAccount sb3 = new SBAccount();
		sb3.setAccountBalance(80000);
		
		SBAccount sb4 = new SBAccount();
		sb4.setAccountBalance(20000);
		
		SBAccount sb5 = new SBAccount();
		sb5.setAccountBalance(10000);
		
		List<SBAccount> accounts = new ArrayList();
		
		accounts.add(sb1);
		accounts.add(sb2);
		accounts.add(sb3);
		accounts.add(sb4);		
		accounts.add(sb5);
		
		
		when(sbaAccountDAOMock.getAllSavingsAccounts()).thenReturn(accounts);
		  
		  
		  
		  assertEquals(3,service.getAccountsbasedonAmount(20000).size());
		
	}

	
	
}
