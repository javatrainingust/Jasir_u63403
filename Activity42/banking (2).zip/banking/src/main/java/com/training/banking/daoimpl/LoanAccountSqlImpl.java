/**
 * LoanAccountSqlImpl
 * SQL implememntation for loan accounts
 * 23/10/2020
 */
package com.training.banking.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.repository.SBAccountsMapper;
import com.training.banking.repository.LoanAccountDao;
import com.training.banking.repository.LoanAccountsMapper;
import com.training.banking.repository.SBAccountDAo;

/**
 * dao imlememntation with sql connection
 * 
 * @author Jasir
 *
 */
@Repository
public class LoanAccountSqlImpl implements LoanAccountDao {

	private DataSource dataSource;

	@Autowired
	private JdbcTemplate jdbcTemplateObject;

	
	/*
	 * @Autowired public void setDataSource(DataSource dataSource) { this.dataSource
	 * = dataSource; jdbcTemplateObject = new JdbcTemplate(dataSource); }
	 */

	/**
	 * query for get all accounts
	 */
	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		String SQL = "select * from loanaccounts";
		List<LoanAccount> accounts = jdbcTemplateObject.query(SQL, new LoanAccountsMapper());

		return accounts;
	}

	/**
	 * query for get one account by account number
	 */
	@Override
	public LoanAccount getLaonAccountByAccountNum(int acNumber) {

		String sql = "SELECT * FROM loanaccounts WHERE accountNumber = ?";
		LoanAccount accounts = (LoanAccount) jdbcTemplateObject.queryForObject(sql, new Object[] { acNumber },
				new LoanAccountsMapper());
		return accounts;
	}

	/**
	 * query for delete one account
	 */
	@Override
	public void deleteLaonAccount(int acNumber) {
		String query = "delete from loanaccounts where accountNumber='" + acNumber + "' ";
		jdbcTemplateObject.update(query);

	}

	/**
	 * query for add accounts
	 */
	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
		String sql = "INSERT INTO savingsaccounts "
				+ "(accountNumber, name, balance,type,tenure,amount,emi,interest) VALUES (?, ?, ?,?,?,?,?,?)";

		jdbcTemplateObject.update(sql,
				new Object[] { loanAccount.getAccountNumber(), loanAccount.getAccountHolderName(),
						loanAccount.getAccountBalance(), loanAccount.getLoanType(), loanAccount.getTenure(),
						loanAccount.getLoanAmount(), loanAccount.getEmi(), loanAccount.getIntrest() });
		return true;
	}

	/**
	 * query for update an account
	 */
	@Override
	public void updateLoanAccount(LoanAccount loanAccount) {
		String query = "update savingsaccounts set  name='" + loanAccount.getAccountHolderName() + "',balance='"
				+ loanAccount.getAccountBalance() + "' where accountNumber='" + loanAccount.getAccountNumber() + "' ";
		jdbcTemplateObject.update(query);

	}

}
