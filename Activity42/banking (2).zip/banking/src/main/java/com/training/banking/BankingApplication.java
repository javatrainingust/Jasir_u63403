/**
 * BankingApplication
 * Springboot main class which used to confguration 
 * 27/10/2020 
 */
package com.training.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * used to run the app
 * @author Jasir
 *
 */
@SpringBootApplication
public class BankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingApplication.class, args);
	}

}
