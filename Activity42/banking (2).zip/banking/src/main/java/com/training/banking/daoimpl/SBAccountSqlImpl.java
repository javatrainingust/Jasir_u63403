/**
 * SavingsAccountSqlImpl
 * SQL implememntation for loan accounts
 * 23/10/2020
 */
package com.training.banking.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.banking.entity.SBAccount;
import com.training.banking.repository.SBAccountsMapper;
import com.training.banking.repository.SBAccountDAo;

/**
 * dao imlememntation with sql connection
 * 
 * @author Jasir
 *
 */
@Repository
public class SBAccountSqlImpl implements SBAccountDAo {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;

	/**
	 * datasource injection
	 * 
	 * @param dataSource
	 */
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	/**
	 * query for get all accounts
	 */
	@Override
	public List<SBAccount> getAllSavingsAccounts() {
		String SQL = "select * from savingsaccounts";
		List<SBAccount> accounts = jdbcTemplateObject.query(SQL, new SBAccountsMapper());

		return accounts;
	}

	/**
	 * query for get an account
	 */
	@Override
	public SBAccount getSBAccountByAccountNum(int acNumber) {

		String sql = "SELECT * FROM savingsaccounts WHERE accountNumber = ?";
		SBAccount accounts = (SBAccount) jdbcTemplateObject.queryForObject(sql, new Object[] { acNumber },
				new SBAccountsMapper());
		return accounts;
	}

	/**
	 * query for delete an account
	 */
	@Override
	public void deleteSavingsAccount(int acNumber) {
		String query = "delete from savingsaccounts where accountNumber='" + acNumber + "' ";
		jdbcTemplateObject.update(query);

	}

	/**
	 * query for add accounts
	 */
	@Override
	public boolean addSavingsAccount(SBAccount sbAccount) {
		String sql = "INSERT INTO savingsaccounts "
				+ "(accountNumber, name, balance,rate,time,interest) VALUES (?, ?, ?,?,?,?)";

		jdbcTemplateObject.update(sql, new Object[] { sbAccount.getAccountNumber(), sbAccount.getAccountHolderName(),
				sbAccount.getAccountBalance(), sbAccount.getRate(), sbAccount.getTime(), sbAccount.getInterest() });
		return true;
	}

	/**
	 * query for update an account
	 */
	@Override
	public void updateSavingsAccount(SBAccount sbAccount) {
		String query = "update savingsaccounts set  name='" + sbAccount.getAccountHolderName() + "',balance='"
				+ sbAccount.getAccountBalance() + "' where accountNumber='" + sbAccount.getAccountNumber() + "' ";
		jdbcTemplateObject.update(query);

	}

}
