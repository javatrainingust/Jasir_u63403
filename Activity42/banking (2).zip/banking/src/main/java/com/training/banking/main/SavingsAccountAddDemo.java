package com.training.banking.main;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.service.SBAccountservice;

public class SavingsAccountAddDemo {

	public static void main(String[] args) {
		
		SBAccountservice service = new SBAccountservice();
		service.addSavingsAccount(new SBAccount(123456710, "Ebin Varghese", 201001.0f));
		service.addSavingsAccount(new SBAccount(123456711, "Allan k", 251001.0f));
		service.addSavingsAccount(new SBAccount(123456712, "Vidhya ", 101001.0f));
		service.addSavingsAccount(new SBAccount(123456713, "Ashley", 231001.0f));
		service.addSavingsAccount(new SBAccount(123456710, "Ebin", 20101.0f));
		
		System.out.println("Printing all Savings accounts");	
		service.getAllSBAccounts();
		System.out.println("---------------------------------------------");	
		service.updateSavingsAccount(new SBAccount(123456713, "Ashley pk", 231005.0f));
		
		System.out.println("Printing all updated Savings accounts");	
		
		service.getAllSBAccounts();

	}

}
