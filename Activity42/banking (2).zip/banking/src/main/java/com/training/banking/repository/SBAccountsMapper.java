/**
 * SBAccountsMapper
 * 
 * row mapper implementation for savings accounts
 * 
 * 23/10/2020
 */
package com.training.banking.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.banking.entity.SBAccount;
/**
 * rowmapper implementation
 * @author Jasir
 *
 */
public class SBAccountsMapper implements RowMapper<SBAccount> {
	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		SBAccount sbAc =  new SBAccount();
		
		sbAc.setAccountBalance(rs.getInt("balance"));
		
		sbAc.setAccountHolderName(rs.getString("name"));
		
		sbAc.setAccountNumber(rs.getInt("accountNumber"));
		
		sbAc.setRate(rs.getFloat("rate"));
		
		sbAc.setTime(rs.getInt("time"));
		
		
		return sbAc;
}}
