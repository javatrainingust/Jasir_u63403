package com.training.banking.exception;

public class InsufficiantMoneyException extends Exception {
	
	float moneyToWithdraw;

	public InsufficiantMoneyException(float moneyToWithdraw) {
		super();
		this.moneyToWithdraw = moneyToWithdraw;
	}

	@Override
	public String toString() {
		return "Insufficiant balance in your account to withdraw " + moneyToWithdraw;
	}
	
	

}
