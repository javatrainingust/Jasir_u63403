package com.training.banking.entity;

public class CurrentAccount extends Account {

}
