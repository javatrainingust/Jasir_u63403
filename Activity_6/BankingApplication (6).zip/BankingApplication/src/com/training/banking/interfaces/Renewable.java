package com.training.banking.interfaces;

public interface Renewable {
	
	public void autoRenewal(int tenure);

}
