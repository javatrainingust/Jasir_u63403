package com.training.banking.util;

public class InterestCalculator {

	public Float calculateInterest(float principle,float rate,int time) {
	
		float intrest = principle*time*rate; 
		
		return intrest;
	}
	
	public Float calculateInterest(float principle,float rate) {
		
		int time =1;
		float intrest = principle*time*rate; 
		
		return intrest;
		
	}
		
	
}
