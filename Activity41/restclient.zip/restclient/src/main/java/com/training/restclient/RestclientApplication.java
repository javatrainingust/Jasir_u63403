/**
 * RestclientApplication
 * 
 * rest client for banking application
 * 
 * 28/10/2020
 */
package com.training.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.training.restclient.entity.SBAccount;
/**
 * rest client implementation
 * @author Jasir
 *
 */
@SpringBootApplication
public class RestclientApplication {

	/**
	 * main method
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		
		
		//getResource();
		//getAllResources();
		//postResource();
		//getAllResources();
//		putResource();
//		getAllResources();
		deleteResource();
		getAllResources();
	}
	/**
	 * To get one account
	 */
	public static void  getResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/bankingapplication/savings/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 123456710);
	     
	    SBAccount result = restTemplate.getForObject(uri, SBAccount.class, params);
	    
	    System.out.println("Account Number: "+result.getAccountNumber());
	    System.out.println("Name: "+result.getAccountHolderName());
	    System.out.println("Balance: "+result.getAccountBalance());
		
		
	}
	
	/**
	 * To get all accounts
	 */
	public static void getAllResources() {
		
		System.out.println("Inside getAllResources() method");
	
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/bankingapplication/savings/accounts";
	    	     
	    	     
	    ResponseEntity<SBAccount[]> response  = restTemplate.getForEntity(uri, SBAccount[].class);
	    
	    SBAccount[] accounts = response.getBody();

	    
	    for(int i=0; i<accounts.length;i++) {
	    	
	    	SBAccount result= (SBAccount)accounts[i];	    
	    	System.out.println("Account Number: "+result.getAccountNumber());
		    System.out.println("Name: "+result.getAccountHolderName());
		    System.out.println("Balance: "+result.getAccountBalance());
	    
	    }
		
		
		
	}
	/**
	 * To add one account
	 */
	public static void postResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/bankingapplication/savings/accounts";
	
		SBAccount pe = new SBAccount(123450000, "Ebin", 201001.0f);
	
		SBAccount result = restTemplate.postForObject( uri, pe, SBAccount.class);
		
		
	}
	
	/**
	 * To update one account
	 */
	public static void putResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/bankingapplication/savings/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 123450000);
	     
	    SBAccount updatedEmployee = new SBAccount(123450000, "Ebin Varghese", 201001.0f);
	    
	     restTemplate.put(uri, updatedEmployee, params);

	}
	/**
	 * To delete an account
	 */
	public static void deleteResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/bankingapplication/savings/accounts/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 123450000);
	     
	     restTemplate.delete(uri, params);
	}


}
