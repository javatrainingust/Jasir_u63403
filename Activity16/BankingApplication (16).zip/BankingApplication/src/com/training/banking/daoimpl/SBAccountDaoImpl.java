/**
 * SBAccountDaoImpl
 * 
 * Implementation for SBAccount DAO operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.banking.entity.SBAccount;
import com.training.banking.repository.SBAccountDAo;

/**Implementation for SBAccount DAO*/
public class SBAccountDaoImpl implements SBAccountDAo {

	List SBAccountList;
	public SBAccountDaoImpl() {
		
		SBAccountList = new ArrayList<SBAccount>();
		SBAccount account1 = new SBAccount(123456710, "Ebin Varghese", 201001.0f);
		SBAccount account2 = new SBAccount(123456711, "Allan k", 251001.0f);
		SBAccount account3 = new SBAccount(123456712, "Vidhya ", 101001.0f);
		SBAccount account4 = new SBAccount(123456713, "Ashley", 231001.0f);
		
		SBAccountList.add(account1);
		SBAccountList.add(account2);
		SBAccountList.add(account3);
		SBAccountList.add(account4);
	}
	
	/**Implementation for get SBAccounts*/
	@Override
	public List<SBAccount> getAllSavingsAccounts() {
		return SBAccountList;
	}

	/**Implementation for get one SBAccounts by account numbers*/
	@Override
	public SBAccount getSBAccountByAccountNum(int AcNum) {
		SBAccount sbAccount =null;
		
		Iterator<SBAccount>   iterator = SBAccountList.iterator();
		
		while(iterator.hasNext()){
			
			SBAccount sb = iterator.next();
			
			if(sb.getAccountNumber()==AcNum){
				
				sbAccount=sb;
				
			}
				
		}

		return sbAccount;
	}

	/**Implementation for delete a SBAccounts by account numbers*/
	@Override
	public void deleteSavingsAccount(int AcNum) {
		
		for(int i=0; i< SBAccountList.size(); i++){
			
			SBAccount sb =(SBAccount)SBAccountList.get(i);
			
			if(sb.getAccountNumber()==AcNum){
				
				SBAccountList.remove(i);
				
			}
			
		}

	}

}

