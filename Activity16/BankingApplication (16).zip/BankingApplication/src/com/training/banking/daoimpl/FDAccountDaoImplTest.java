package com.training.banking.daoimpl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.FDAccount;

class FDAccountDaoImplTest {
	List fdAccountListTest;
	public FDAccountDaoImplTest() {
		fdAccountListTest = new ArrayList<FDAccount>();
		FDAccount account1 = new FDAccount(123456789, "Albin Jose", 10000.0f, 2, true, 2022);
		FDAccount account2 = new FDAccount(123456790, "Manohar k k", 15000.0f, 1, true, 2021);
		FDAccount account3 = new FDAccount(123456791, "Raguvaran", 18000.0f, 3, true, 2023);
		FDAccount account4 = new FDAccount(123456792, "Unni P", 20000.0f, 5, true, 2025);
	
		fdAccountListTest.add(account1);
		fdAccountListTest.add(account2);
		fdAccountListTest.add(account3);
		fdAccountListTest.add(account4);
	}
	@Test
	void testGetAllFixedAccounts() {
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		FDAccountDaoImpl daoImp = new FDAccountDaoImpl();
		actualList = daoImp.getAllFixedAccounts();
		assertEquals(actualList.size(), fdAccountListTest.size());
	}

	@Test
	void testGetFdAccountByAccountNum() {
		FDAccount actual = (FDAccount)fdAccountListTest.get(2);
		FDAccountDaoImpl daoImp = new FDAccountDaoImpl();
		FDAccount expected = daoImp.getFdAccountByAccountNum(123456791);
		assertEquals(actual.getAccountHolderName(), expected.getAccountHolderName());
	}

	@Test
	void testDeleteFixedAccount() {
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		FDAccountDaoImpl daoImp = new FDAccountDaoImpl();
		daoImp.deleteFixedAccount(123456792);
		actualList = daoImp.getAllFixedAccounts();
		assertEquals(actualList.size(), fdAccountListTest.size()-1);
	}

}
