package com.training.banking.daoimpl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.LoanAccount;

class LoanAccountDaoImplTest {
	List loanAccountListTest;
	public LoanAccountDaoImplTest() {
		loanAccountListTest = new ArrayList<LoanAccount>();
		LoanAccount account1 = new LoanAccount(123456720, "Jaleel", 45000.15f, "Educational", 2, 100000.0f);
		LoanAccount account2 = new LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f);
		LoanAccount account3 = new LoanAccount(123456722, "Ashker", 25000.15f, "Car", 4, 500000.0f);
		LoanAccount account4 = new LoanAccount(123456723, "Fathima", 75000.15f, "Educational", 2, 100000.0f);
		
		loanAccountListTest.add(account1);
		loanAccountListTest.add(account2);
		loanAccountListTest.add(account3);
		loanAccountListTest.add(account4);
	}
	@Test
	void testGetAllLoanAccounts() {
		List<LoanAccount> actualList = new ArrayList<LoanAccount>();
		LoanAccountDaoImpl daoImp = new LoanAccountDaoImpl();
		actualList = daoImp.getAllLoanAccounts();
		assertEquals(actualList.size(), loanAccountListTest.size());
	}

	@Test
	void testGetLaonAccountByAccountNum() {
		LoanAccount actual = (LoanAccount) loanAccountListTest.get(2);
		LoanAccountDaoImpl daoImp = new LoanAccountDaoImpl();
		LoanAccount expected = daoImp.getLaonAccountByAccountNum(123456722);
		assertEquals(actual.getAccountHolderName(), expected.getAccountHolderName());
	}

	@Test
	void testDeleteLaonAccount() {
		List<LoanAccount> actualList = new ArrayList<LoanAccount>();
		LoanAccountDaoImpl daoImp = new LoanAccountDaoImpl();
		daoImp.deleteLaonAccount(123456723);
		actualList = daoImp.getAllLoanAccounts();
		assertEquals(actualList.size(), loanAccountListTest.size()-1);
	}

}
