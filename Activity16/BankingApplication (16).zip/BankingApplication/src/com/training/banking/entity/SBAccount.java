/**
 * SBAccount
 * 
 * Class for handle the saving account
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

import com.training.banking.interfaces.ICalculateInterest;

/**sub class for SB account derived from account class */
public class SBAccount extends Account {

	private float rate = .4f;
	private int time = 1;
	private float interest = 13.5f;
	
	/**get interest*/
	public float getInterest() {
		return interest;
	}

	/**Parameterized constructor*/
	public SBAccount(int accountNumber, String accountHolderName, float accountBalance) {
		super(accountNumber, accountHolderName, accountBalance);
		
	}

	
	/**non-Parameterized constructor*/
	public SBAccount() {
		System.out.println("inside SBAccount non-arg costructor");
	}

	/**get the value of rate*/
	public float getRate() {
		return rate;
	}
	
	/**assign  value to rate*/
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	/**get the value of time*/
	public int getTime() {
		return time;
	}
	
	/**assign  value to time*/
	public void setTime(int time) {
		this.time = time;
	}
	
	/**overriding method for calculate interest*/
	public void calculateInterest(ICalculateInterest calcs) {
		
		this.interest = calcs.calculateInterest(this.getAccountBalance(),rate);
		System.out.println("your SBAccount will have RS "+this.interest+ " as interest  with rate "+rate);
		
	}
}
