/**
 * Account
 * 
 * Class for handle the accounts
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

import com.training.banking.interfaces.ICalculateInterest;

/**Base class for handle account*/
public class Account {

	
	private int accountNumber;
	private String accountHolderName;
	private float accountBalance;
	
	
	/**base class constructor*/

	public Account(int accountNumber, String accountHolderName, float accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountBalance = accountBalance;
	}

	


	public Account() {
		super();
	}




	/**get the account number*/
	public int getAccountNumber() {
		return accountNumber;
	}



	/**set the account number*/
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	/**get account holder name*/
	public String getAccountHolderName() {
		return accountHolderName;
	}


	/**assign account holder name*/
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	/**get account balance */
	public float getAccountBalance() {
		return accountBalance;
	}


	/**To withdraw money from account*/
	public void withdrawMoney(float amountToWithdraw) {
		
		this.accountBalance = this.accountBalance - amountToWithdraw;
		System.out.println("Amount to Withdraw "+ amountToWithdraw);
		System.out.println("Available balanace is "+this.accountBalance);
	}

	/**overriden method for calculate interest*/
	public void calculateInterest(ICalculateInterest cal) {
		
		System.out.println("inside base class");
	}

	
	
}
