/**
 * CurrentAccountService
 * 
 * Business logics for Current Account 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.service;

import java.util.Iterator;
import java.util.List;

import com.training.banking.daoimpl.CurrentAaccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.repository.CurrentAccountDao;

/**Service class for FD account*/
public class CurrentAccountService {

	CurrentAccountDao CurrentAccountDao;
	public CurrentAccountService(){
			
		CurrentAccountDao = new CurrentAaccountDaoImpl();
			
		} 
	
	/**Fetch all Current Accounts*/
	public List<CurrentAccount> getAllCurAccounts() {
	
		List curentAccountList = CurrentAccountDao.getAllCurrentAccount();
		
		Iterator<CurrentAccount> iterator = curentAccountList.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount fd = iterator.next();
			
			System.out.println("Name = "+fd.getAccountHolderName());
			System.out.println("Account Number ="+fd.getAccountNumber());
			System.out.println("Account Balance = "+fd.getAccountBalance());
			
			}			

		return curentAccountList;
		
	}
		
	/**Fetch one Current account by its account number*/
	public CurrentAccount getCurAccountByAccountNum(int accountNumber) {
		
		CurrentAccount fd = CurrentAccountDao.getCurrentAccountByAccountNum(accountNumber);
				
		System.out.println("Name = "+fd.getAccountHolderName());
		System.out.println("Account Number ="+fd.getAccountNumber());
		System.out.println("Account Balance = "+fd.getAccountBalance());
		
		return fd;
		
	}
		
	/**Remove one Current account by its account number*/	
	public void deleteCurAccount(int accountNumber) {
		
		CurrentAccountDao.deleteCurrentAccount(accountNumber);
		
	}	

}
