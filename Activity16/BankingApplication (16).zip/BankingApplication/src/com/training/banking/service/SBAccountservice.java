/**
 * SBAccountService
 * 
 * Business logics for SBAccount 
 *
 * 06/10/2020
 * 
 */
package com.training.banking.service;

import java.util.Iterator;
import java.util.List;

import com.training.banking.daoimpl.FDAccountDaoImpl;
import com.training.banking.daoimpl.SBAccountDaoImpl;
import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.repository.FDAccountDao;
import com.training.banking.repository.SBAccountDAo;

/** Service class for Savings account */
public class SBAccountservice {

	SBAccountDAo sbAccountDao;

	public SBAccountservice() {

		sbAccountDao = new SBAccountDaoImpl();
	}

	/** Fetch all SB Accounts */
	public List<SBAccount> getAllSBAccounts() {

		List sbAccountList = sbAccountDao.getAllSavingsAccounts();

		Iterator<SBAccount> iterator = sbAccountList.iterator();

		while (iterator.hasNext()) {

			SBAccount sb = iterator.next();

			System.out.println("Name = " + sb.getAccountHolderName());
			System.out.println("Account Number =" + sb.getAccountNumber());
			System.out.println("Account Balance = " + sb.getAccountBalance());

		}

		return sbAccountList;

	}

	/** Fetch one Savings account by its account number */
	public SBAccount getSBAccountByAccountNum(int accountNumber) {

		SBAccount sb = sbAccountDao.getSBAccountByAccountNum(accountNumber);

		System.out.println("Name = " + sb.getAccountHolderName());
		System.out.println("Account Number =" + sb.getAccountNumber());
		System.out.println("Account Balance = " + sb.getAccountBalance());

		return sb;

	}

	/** Remove one Savings account by its account number */
	public void deleteSBAccount(int accountNumber) {

		sbAccountDao.deleteSavingsAccount(accountNumber);

	}

}
