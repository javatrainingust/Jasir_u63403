/**
 * FDAccountService
 * 
 * Business logics for FDAccount 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.service;

import java.util.Iterator;
import java.util.List;

import com.training.banking.daoimpl.FDAccountDaoImpl;
import com.training.banking.entity.FDAccount;
import com.training.banking.repository.FDAccountDao;
/**Service class for FD account*/
public class FDAccountService {

	FDAccountDao fdAccountDao;
	public FDAccountService(){
			
		fdAccountDao = new FDAccountDaoImpl();
			
		} 
	
	/**Fetch all FD Accounts*/
	public List<FDAccount> getAllFixedAccounts() {
	
		List fdAccountList = fdAccountDao.getAllFixedAccounts();
		
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		
		while(iterator.hasNext()){
			
			FDAccount fd = iterator.next();
			
			System.out.println("Name = "+fd.getAccountHolderName());
			System.out.println("Account Number ="+fd.getAccountNumber());
			System.out.println("Account Balance = "+fd.getAccountBalance());
			
			}			

		return fdAccountList;
		
	}
		
	/**Fetch one Fixed account by its account number*/
	public FDAccount getFdAccountByAccountNum(int accountNumber) {
		
		FDAccount fd = fdAccountDao.getFdAccountByAccountNum(accountNumber);
				
		System.out.println("Name = "+fd.getAccountHolderName());
		System.out.println("Account Number ="+fd.getAccountNumber());
		System.out.println("Account Balance = "+fd.getAccountBalance());
		
		return fd;
		
	}
		
	/**Remove one Fixed account by its account number*/	
	public void deleteFixedAccount(int accountNumber) {
		
		fdAccountDao.deleteFixedAccount(accountNumber);
		
	}	

}
