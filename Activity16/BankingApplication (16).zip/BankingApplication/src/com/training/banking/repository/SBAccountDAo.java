/**
 * FDAccountDao
 * 
 * Interface for SBAccount repository 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.repository;

import java.util.List;

import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;
/**Interface for SB Account*/
public interface SBAccountDAo {

	public List<SBAccount> getAllSavingsAccounts();
	public SBAccount getSBAccountByAccountNum(int AcNum);
	public void deleteSavingsAccount(int AcNum);
}
