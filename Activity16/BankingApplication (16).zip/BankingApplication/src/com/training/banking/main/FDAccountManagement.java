/**
 * FDAccountManagement
 * 
 * Main method for FDAccount 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.main;

import com.training.banking.service.FDAccountService;

public class FDAccountManagement {

	public static void main(String[] args) {
		FDAccountService fdAccount =  new FDAccountService();
		System.out.println("\nAll Accounts\n");
		fdAccount.getAllFixedAccounts();
		System.out.println("\nOne by account number\n");
		fdAccount.getFdAccountByAccountNum(123456789);
		fdAccount.deleteFixedAccount(123456790);
		System.out.println("\nAfter Delete\n");
		fdAccount.getAllFixedAccounts();
	}

}
