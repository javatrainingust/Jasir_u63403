package com.training.banking.testcase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.banking.daoimpl.FDAccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.FDAccount;
import com.training.banking.service.FDAccountService;

class FDAccountServiceTest {
	List fdAccountListTest;
	FDAccountService service;
	public FDAccountServiceTest() {
		service = new FDAccountService();
		service.addFixedAccount(new FDAccount(123456789, "Albin Jose", 10000.0f, 2, true, 2022));
		service.addFixedAccount(new FDAccount(123456790, "Manohar k k", 15000.0f, 1, true, 2021));
		service.addFixedAccount(new FDAccount(123456791, "Raguvaran", 20000.0f, 3, true, 2023));
		service.addFixedAccount(new FDAccount(123456792, "Bunny P", 18000.0f, 5, true, 2025));		
		fdAccountListTest = service.getAllFixedAccounts();
	}
	
	@Test
	void testaddFixedAccount() {
		FDAccountDaoImpl daoImpl = new FDAccountDaoImpl();
		boolean actualTrueValue = daoImpl.addFixedAccount(new FDAccount(123456795, "Jasir", 20000.0f, 3, true, 2023));
		boolean actualFalseValue = daoImpl.addFixedAccount(new FDAccount(123456795, "Bunny P", 18000.0f, 5, true, 2025));
		assertTrue(actualTrueValue);
		assertFalse(actualFalseValue);
	}
	
	@Test
	void testGetAllFixedAccounts() {
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		actualList = service.getAllFixedAccounts();
		assertEquals(actualList.size(), fdAccountListTest.size());
	}

	@Test
	void testGetFdAccountByAccountNum() {
		String expectedVlaue = "Raguvaran";
		FDAccount actualValue = service.getFdAccountByAccountNum(123456791);
		assertEquals(expectedVlaue, actualValue.getAccountHolderName());
	}

	@Test
	void testDeleteFixedAccount() {
		int expectedValue = 3;
		List<FDAccount> actualList = new ArrayList<FDAccount>();
		service.deleteFixedAccount(123456792);
		actualList = service.getAllFixedAccounts();
		assertEquals(expectedValue,actualList.size());
	}

	@Test
	void testGetAllFixedAccountsSortedByNames() {
		String expectedValue = "Albin Jose";
		List<FDAccount> fixedAccount = service.getAllFixedAccountsSortedByNames();
		String actualValue = fixedAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllFixedAccountsSortedByBalance() {
		float expectedValue = 10000.0f;
		List<FDAccount> fixedAccount = service.getAllFixedAccountsSortedByBalance();
		float actualValue = fixedAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
