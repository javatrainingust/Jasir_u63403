package com.training.banking.testcase;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.training.banking.daoimpl.CurrentAaccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.service.CurrentAccountService;

class CurrentAaccountServiceTest {
	List currentAccountListTest;
	CurrentAccountService service;
	public CurrentAaccountServiceTest() {
		service = new CurrentAccountService();
		
        currentAccountListTest = new ArrayList<CurrentAccount>();

		service.addCurrentAccount(new CurrentAccount(123456730, "Sabith", 10000.0f, 5000.0f));
		service.addCurrentAccount(new CurrentAccount(123456731, "Arun", 15000.0f, 8000.0f));
		service.addCurrentAccount(new CurrentAccount(123456732, "Anoop", 20000.0f, 6000.0f));
		service.addCurrentAccount(new CurrentAccount(123456734, "Hisam", 11000.0f, 7000.0f));
		currentAccountListTest = service.getAllCurAccounts();
	}
	
	
	@Test
	void testaddCurrentAccount() {
		CurrentAaccountDaoImpl daoImpl = new CurrentAaccountDaoImpl();
		boolean actualTrueValue = daoImpl.addCurrentAccount(new CurrentAccount(123456733, "Jasir", 10000.0f, 5000.0f));
		boolean actualFalseValue = daoImpl.addCurrentAccount(new CurrentAccount(123456733, "Alan", 20300.0f, 65000.0f));
		assertTrue(actualTrueValue);
		assertFalse(actualFalseValue);
	}
	
	@Test
	void testGetAllCurrentAccount() {
		List<CurrentAccount> actualList = new ArrayList<CurrentAccount>();
		actualList = service.getAllCurAccounts();
		assertEquals( currentAccountListTest.size(),actualList.size());
	}

	@Test
	void testGetCurrentAccountByAccountNum() {
		String expectedValue = "Anoop";
		CurrentAccount actualValue = service.getCurAccountByAccountNum(123456732);
		assertEquals(expectedValue, actualValue.getAccountHolderName());
	}

	@Test
	void testDeleteCurrentAccount() {
		List<CurrentAccount> actualList = new ArrayList<CurrentAccount>();
		int expectedValue = 3;
		service.deleteCurAccount(123456730);
		actualList = service.getAllCurAccounts();
		assertEquals(expectedValue,actualList.size());
	}
	
	@Test
	void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue = "Anoop";
		List<CurrentAccount> currentAccount = service.getAllCurrentAccountsSortedByNames();
		String actualValue = currentAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllCurrentAccountsSortedByBalance() {
		float expectedValue = 10000.0f;
		List<CurrentAccount> currentAccount = service.getAllCurrentAccountsSortedByBalance();
		float actualValue = currentAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}


}
