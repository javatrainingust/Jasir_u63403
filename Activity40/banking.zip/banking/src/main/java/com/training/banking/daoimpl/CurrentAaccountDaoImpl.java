/**
 * CurrentAaccountDaoImpl
 * 
 * Implementation for Current Account DAO operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.repository.CurrentAccountDao;

/**
 * Implementation for LaonAccount DAO
 */
@Repository
public class CurrentAaccountDaoImpl implements CurrentAccountDao {

	List currentAccountList;
	private Set currentAccountSet;

	/**
	 * Constructor LaonAccount DAO
	 */
	public CurrentAaccountDaoImpl() {
		currentAccountList = new ArrayList<CurrentAccount>();
		currentAccountSet = new HashSet<CurrentAccount>();

		
		  CurrentAccount account1 = new CurrentAccount(123456730, "Sabith", 10000.0f,
		  5000.0f); CurrentAccount account2 = new CurrentAccount(123456731, "Arun",
		  15000.0f, 8000.0f); CurrentAccount account3 = new CurrentAccount(123456732,
		  "Anoop", 20000.0f, 6000.0f); CurrentAccount account4 = new
		  CurrentAccount(123456734, "Hisam", 11000.0f, 7000.0f);
		  
		  currentAccountList.add(account1); currentAccountList.add(account2);
		  currentAccountList.add(account3); currentAccountList.add(account4);
		 
	}

	/**
	 * Implementation for get Current Accounts
	 */
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		return currentAccountList;
	}

	/**
	 * Implementation for get one Current Account by account numbers
	 */
	@Override
	public CurrentAccount getCurrentAccountByAccountNum(int acNumber) {
		CurrentAccount currentAccount = null;

		Iterator<CurrentAccount> iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount cuurentAc = iterator.next();

			if (cuurentAc.getAccountNumber() == acNumber) {

				currentAccount = cuurentAc;

			}

		}

		return currentAccount;
	}

	/**
	 * Implementation for delete a Current Account by account numbers
	 */
	@Override
	public void deleteCurrentAccount(int acNumber) {

		for (int i = 0; i < currentAccountList.size(); i++) {

			CurrentAccount cuurentAc = (CurrentAccount) currentAccountList.get(i);

			if (cuurentAc.getAccountNumber() == acNumber) {

				currentAccountList.remove(i);

			}

		}

	}

	/**
	 * method for add current account to SET to avoid duplication and then add to
	 * List
	 */
	@Override
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		boolean isAdded = currentAccountSet.add(currentAccount);

		if (isAdded) {
			currentAccountList.add(currentAccount);
		}
		return isAdded;
	}

	/**
	 * Update the existing current account
	 */
	@Override
	public void updateCurrentAccount(CurrentAccount currentAccount) {

		Iterator iterator = currentAccountList.iterator();

		while (iterator.hasNext()) {

			CurrentAccount ca = (CurrentAccount) iterator.next();

			if (ca.getAccountNumber() == currentAccount.getAccountNumber()) {

				ca.setAccountHolderName(currentAccount.getAccountHolderName());
				ca.setAccountNumber(currentAccount.getAccountNumber());
				ca.setAccountBalance(currentAccount.getAccountBalance());
				ca.setOverDraftLimit(currentAccount.getOverDraftLimit());

			}
		}
	}

}
