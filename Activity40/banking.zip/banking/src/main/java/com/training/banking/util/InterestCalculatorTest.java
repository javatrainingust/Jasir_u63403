package com.training.banking.util;


import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;

class InterestCalculatorTest {

	@Test
	void testCalculateInterestFloatFloatInt() {
		
		FDAccount fdAc = new FDAccount();
		fdAc.setRate(0.75f);
		fdAc.setTenure(1);
		InterestCalculator calculator = new InterestCalculator();
		float expectedValue = 7500.0f;
		fdAc.calculateInterest(calculator);
		float actualValue = fdAc.getInterest();
		assertEquals(expectedValue, actualValue);
		
	}

	@Test
	void testCalculateInterestFloatFloat() {
		SBAccount sbAac = new SBAccount();
		sbAac.setRate(0.4f);
		InterestCalculator calculator = new InterestCalculator();
		float expectedValue = 4000.0f;
		sbAac.calculateInterest(calculator);
		float actualValue = sbAac.getInterest();
		assertEquals(expectedValue, actualValue);
	}

}
