/**
 * Account
 * 
 * Class for handle the accounts
 *
 * 28/09/2020
 * 
*/
package com.training.banking.entity;

import com.training.banking.exception.InsufficiantMoneyException;
import com.training.banking.interfaces.ICalculateInterest;

/**
 * Base class for handle account
*/
public class Account {

	private int accountNumber;
	private String accountHolderName;
	private float accountBalance;
	
	
	/**
	 * base class constructor
	*/
	public Account(int accountNumber, String accountHolderName, float accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountBalance = accountBalance;
	}

	/**
	 * base class defualt constructor
	*/
	public Account() {
		super();
	}
	/**
	 * set the account balance
	*/
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}

	/**
	 * get the account number
	*/
	public int getAccountNumber() {
		return accountNumber;
	}

	/**
	 * set the account number
	*/
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	/**
	 * get account holder name
	*/
	public String getAccountHolderName() {
		return accountHolderName;
	}


	/**
	 * assign account holder name
	*/
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}


	/**
	 * get account balance
	*/
	public float getAccountBalance() {
		return accountBalance;
	}


	/**
	 * To withdraw money from account
	*/
	public void withdrawMoney(float amountToWithdraw) throws InsufficiantMoneyException {
		
		if (amountToWithdraw > this.accountBalance) {
			
			throw new InsufficiantMoneyException(amountToWithdraw);
		}
		
		else {
			
		this.accountBalance = this.accountBalance - amountToWithdraw;
		System.out.println("Amount to Withdraw "+ amountToWithdraw);
		System.out.println("Available balanace is "+this.accountBalance);
		}
	}

	/**
	 * overriden method for calculate interest
	*/
	public void calculateInterest(ICalculateInterest cal) {
		
		System.out.println("inside base class");
	}

	/**
	 * Implementation of hash code method for avoiding duplication in SET
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		return result;
	}
	/**
	 * Implementation of equals method for avoiding duplication in SET
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber != other.accountNumber)
			return false;
		return true;
	}	
	
}
