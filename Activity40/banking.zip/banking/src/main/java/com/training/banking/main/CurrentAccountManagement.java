/**
 * CurrentAccountManagement
 * 
 * Main method for Current Account 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.main;

import com.training.banking.service.CurrentAccountService;

/**
 * Main class
 */
public class CurrentAccountManagement {

	public static void main(String[] args) {
		CurrentAccountService currentAccount =  new CurrentAccountService();
		System.out.println("\nAll Accounts\n");
		currentAccount.getAllCurAccounts();
		System.out.println("\nAfter Sorting by name\n");
		currentAccount.getAllCurrentAccountsSortedByNames();
		System.out.println("\nAfter Sorting bye account balance\n");
		currentAccount.getAllCurrentAccountsSortedByBalance();
		System.out.println("\nOne by account number\n");
		currentAccount.getCurAccountByAccountNum(123456730);
		currentAccount.deleteCurAccount(123456731);
		System.out.println("\nAfter Delete\n");
		currentAccount.getAllCurAccounts();

	}

}
