package com.training.banking.interfaces;

public interface ICalculateInterest {
	
	public Float calculateInterest(float principle,float rate,int time);
	public Float calculateInterest(float principle,float rate);

}
