package com.training.banking.entity;

public class LoanAccount extends Account{
	
	private String loanType;
	private int tenure;
	private float loanAmount;
	private float emi;
	private float intrest = 13;
	
	
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	public float getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(float loanAmount) {
		this.loanAmount = loanAmount;
	}

	public void calculate_emi() {
		float emi_;
		float p= this.loanAmount;
		int n=this.tenure;
		
		
	//just_simple_claculation
		emi_ = p/n;
		
		this.emi = emi_;
		
		
		
	}
	public float getEmi() {
		return emi;
	}
}
