/**
 * GenericService
 * 
 * type cast 
 *
 * 29/09/2020
 * 
*/
package com.training.banking.service;


import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.util.InterestCalculator;

public class GenericService {
	
	public static void main(String[] args) {
		SBAccount sbac = new SBAccount(0.3f);
		FDAccount fdac = new FDAccount(1, 0.7f);
		
		InterestCalculator calculator = new InterestCalculator();
		
		sbac.calculateInterest(calculator);
		fdac.calculateInterest(calculator);
		
	}
}
