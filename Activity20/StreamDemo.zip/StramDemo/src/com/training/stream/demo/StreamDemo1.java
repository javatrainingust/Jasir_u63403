/**
 * StreamDemo1
 * example of streams in java
 */
package com.training.stream.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * 
 * @author Jasir
 * sample class for stream demo
 */
public class StreamDemo1 {

	public static void main(String[] args) {
		List<String> students = new ArrayList<String>();
		students.add("Vinoth");
		students.add("Suresh");
		students.add("Jane");
		students.add("Roshan");
		Stream<String> stdStream = students.stream();
		
		Long stringCount = stdStream.count();
		System.out.println("number of string objects "+stringCount);
	}

}
