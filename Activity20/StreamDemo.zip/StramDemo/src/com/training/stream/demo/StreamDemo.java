/**
 * StreamDemo
 * 
 * Stream example demo
 */
package com.training.stream.demo;

import java.util.Arrays;
import java.util.stream.Stream;

/**
 * 
 * @author Jasir
 * sample class for stream
 */
public class StreamDemo {

	public static void main(String[] args) {
		
		String [] students = {"Vinoth","Suresh","Jane","Roshan"};
		
		Stream<String> streamArray = Arrays.stream(students);
		
		System.out.println("no. of elements "+streamArray.count());

	}

}
