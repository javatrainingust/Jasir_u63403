/**
 * SBAccountComparator
 * 
 * Sort savings account based account balance
 * 
 * 07/10/2020
 */
package com.training.banking.util;

import java.util.Comparator;

import com.training.banking.entity.Account;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.SBAccount;
/***
 * 
 * @author Jasir
 * Comparator class for sort based on account balance 
 */
public class SBAccountComparator implements Comparator<SBAccount> {

	/**
	 * Implementation for sort by account account balance
	 */
	@Override
	public int compare(SBAccount o1, SBAccount o2) {
		return (int) (o1.getAccountBalance()-o2.getAccountBalance());
	}

}
