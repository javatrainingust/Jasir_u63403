/**
 * LoanAccountManagement
 * 
 * Main method for LoanAccount 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.main;

import com.training.banking.service.LoanAccountService;

/**Main class
 * 
 */
public class LoanAccountManagement {

	public static void main(String[] args) {
		LoanAccountService loanAccount =  new LoanAccountService();
		System.out.println("\nAll Accounts\n");
		loanAccount.getAllLoanAccounts();
		System.out.println("\nAfter Sorting bye account Name\n");
		loanAccount.getAllLoanAccountsSortedByNames();
		System.out.println("\nAfter Sorting bye account balance\n");
		loanAccount.getAllLoanAccountsSortedByBalance();
		System.out.println("\nOne by account number\n");
		loanAccount.getLoanAccountByAccountNum(123456720);
		loanAccount.deleteSBAccount(123456721);
		System.out.println("\nAfter Delete\n");
		loanAccount.getAllLoanAccounts();

	}

}
