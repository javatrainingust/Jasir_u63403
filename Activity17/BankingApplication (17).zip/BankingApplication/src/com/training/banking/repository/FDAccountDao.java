/**
 * FDAccountDao
 * 
 * Interface for FDAccount repository 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.repository;

import java.util.List;

import com.training.banking.entity.FDAccount;
/**
 * Interface for FD Account
 */
public interface FDAccountDao {
	
	public List<FDAccount> getAllFixedAccounts();
	public FDAccount getFdAccountByAccountNum(int acNumber);
	public void deleteFixedAccount(int acNumber);
}
