/**
 * LoanAccountDao
 * 
 * Interface for Loan Account 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.repository;

import java.util.List;

import com.training.banking.entity.LoanAccount;

/**
 * Interface for Loan Account
 */
public interface LoanAccountDao {

	public List<LoanAccount> getAllLoanAccounts();
	public LoanAccount getLaonAccountByAccountNum(int acNumber);
	public void deleteLaonAccount(int acNumber);
}
