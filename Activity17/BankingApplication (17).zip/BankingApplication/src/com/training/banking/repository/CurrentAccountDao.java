/**
 * CurrentAccountDao
 * 
 * Interface for Current Account 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.repository;

import java.util.List;

import com.training.banking.entity.CurrentAccount;

/**
 * Interface for Current Account
 */
public interface CurrentAccountDao {
	public List<CurrentAccount> getAllCurrentAccount();
	public CurrentAccount getCurrentAccountByAccountNum(int acNumber);
	public void deleteCurrentAccount(int acNumber);
}
