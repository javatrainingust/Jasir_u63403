package com.training.banking.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.FDAccount;

class FDAccountServiceTest {

	@Test
	void testGetAllFixedAccountsSortedByNames() {
		String expectedValue = "Albin Jose";
		FDAccountService acService = new FDAccountService();
		List<FDAccount> fixedAccount = acService.getAllFixedAccountsSortedByNames();
		String actualValue = fixedAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllFixedAccountsSortedByBalance() {
		float expectedValue = 10000.0f;
		FDAccountService acService = new FDAccountService();
		List<FDAccount> fixedAccount = acService.getAllFixedAccountsSortedByBalance();
		float actualValue = fixedAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
