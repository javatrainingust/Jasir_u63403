package com.training.banking.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.SBAccount;

class SBAccountserviceTest {

	@Test
	void testGetAllSavingsAccountsSortedByNames() {
		String expectedValue = "Allan k";
		SBAccountservice acService = new SBAccountservice();
		List<SBAccount> savingsAccount = acService.getAllSavingsAccountsSortedByNames();
		String actualValue = savingsAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllSavingsAccountsSortedByBalance() {
		float expectedValue = 101001.0f;
		SBAccountservice acService = new SBAccountservice();
		List<SBAccount> savingsAccount = acService.getAllSavingsAccountsSortedByBalance();
		float actualValue = savingsAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
