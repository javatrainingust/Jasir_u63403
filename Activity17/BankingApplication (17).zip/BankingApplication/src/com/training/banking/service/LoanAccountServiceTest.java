package com.training.banking.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.LoanAccount;

class LoanAccountServiceTest {

	@Test
	void testGetAllLoanAccountsSortedByNames() {
		String expectedValue = "Ashker";
		LoanAccountService acService = new LoanAccountService();
		List<LoanAccount> loanAccount = acService.getAllLoanAccountsSortedByNames();
		String actualValue = loanAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllLoanAccountsSortedByBalance() {
		float expectedValue = 25000.15f;
		LoanAccountService acService = new LoanAccountService();
		List<LoanAccount> loanAccount = acService.getAllLoanAccountsSortedByNames();
		float actualValue = loanAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
