package com.training.banking.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.CurrentAccount;

class CurrentAccountServiceTest {

	@Test
	void testGetAllCurrentAccountsSortedByNames() {
		String expectedValue = "Anoop";
		CurrentAccountService acService = new CurrentAccountService();
		List<CurrentAccount> currentAccount = acService.getAllCurrentAccountsSortedByNames();
		String actualValue = currentAccount.get(0).getAccountHolderName();
		assertEquals(expectedValue, actualValue);
	}

	@Test
	void testGetAllCurrentAccountsSortedByBalance() {
		float expectedValue = 10000.0f;
		CurrentAccountService acService = new CurrentAccountService();
		List<CurrentAccount> currentAccount = acService.getAllCurrentAccountsSortedByBalance();
		float actualValue = currentAccount.get(0).getAccountBalance();
		assertEquals(expectedValue, actualValue);
	}

}
