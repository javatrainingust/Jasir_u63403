package com.training.banking.daoimpl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.SBAccount;

class SBAccountDaoImplTest {
	List SBAccountListTest;
	public SBAccountDaoImplTest() {
		
		SBAccountListTest = new ArrayList<SBAccount>();
		SBAccount account1 = new SBAccount(123456710, "Ebin Varghese", 201001.0f);
		SBAccount account2 = new SBAccount(123456711, "Allan k", 251001.0f);
		SBAccount account3 = new SBAccount(123456712, "Vidhya ", 101001.0f);
		SBAccount account4 = new SBAccount(123456713, "Ashley", 231001.0f);
		
		SBAccountListTest.add(account1);
		SBAccountListTest.add(account2);
		SBAccountListTest.add(account3);
		SBAccountListTest.add(account4);
	}
	@Test
	void testGetAllSavingsAccounts() {
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		SBAccountDaoImpl daoImp = new SBAccountDaoImpl();
		actualList = daoImp.getAllSavingsAccounts();
		assertEquals(actualList.size(), SBAccountListTest.size());
	}

	@Test
	void testGetSBAccountByAccountNum() {
		SBAccount actual = (SBAccount) SBAccountListTest.get(2);
		SBAccountDaoImpl daoImp = new SBAccountDaoImpl();
		SBAccount expected = daoImp.getSBAccountByAccountNum(123456712);
		assertEquals(actual.getAccountHolderName(), expected.getAccountHolderName());
	}

	@Test
	void testDeleteSavingsAccount() {
		List<SBAccount> actualList = new ArrayList<SBAccount>();
		SBAccountDaoImpl daoImp = new SBAccountDaoImpl();
		daoImp.deleteSavingsAccount(123456713);
		actualList = daoImp.getAllSavingsAccounts();
		assertEquals(actualList.size(), SBAccountListTest.size()-1);
	}

}
