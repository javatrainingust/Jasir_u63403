package com.training.banking.daoimpl;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.banking.entity.CurrentAccount;

class CurrentAaccountDaoImplTest {
	List currentAccountListTest;
	public CurrentAaccountDaoImplTest() {
		currentAccountListTest = new ArrayList<CurrentAccount>();
		CurrentAccount account1 = new  CurrentAccount(123456730, "Sabith", 10000.0f, 5000.0f);
		CurrentAccount account2 = new  CurrentAccount(123456731, "Arun", 15000.0f, 8000.0f);
		CurrentAccount account3 = new  CurrentAccount(123456732, "Anoop", 20000.0f, 6000.0f);
		CurrentAccount account4 = new  CurrentAccount(123456734, "Hisam", 11000.0f, 7000.0f);
		
		currentAccountListTest.add(account1);
		currentAccountListTest.add(account2);
		currentAccountListTest.add(account3);
		currentAccountListTest.add(account4);
	}
	
	@Test
	void testGetAllCurrentAccount() {
		
		List<CurrentAccount> actualList = new ArrayList<CurrentAccount>();
		CurrentAaccountDaoImpl daoImp = new CurrentAaccountDaoImpl();
		actualList = daoImp.getAllCurrentAccount();
		assertEquals( currentAccountListTest.size(),actualList.size());
	}

	@Test
	void testGetCurrentAccountByAccountNum() {
		CurrentAccount expectedValue = (CurrentAccount) currentAccountListTest.get(2);
		CurrentAaccountDaoImpl daoImp = new CurrentAaccountDaoImpl();
		CurrentAccount actualValue = daoImp.getCurrentAccountByAccountNum(123456732);
		assertEquals(expectedValue.getAccountHolderName(), actualValue.getAccountHolderName());
	}

	@Test
	void testDeleteCurrentAccount() {
		List<CurrentAccount> actualList = new ArrayList<CurrentAccount>();
		CurrentAaccountDaoImpl daoImp = new CurrentAaccountDaoImpl();
		daoImp.deleteCurrentAccount(123456730);
		actualList = daoImp.getAllCurrentAccount();
		assertEquals(currentAccountListTest.size()-1,actualList.size());
	}

}
