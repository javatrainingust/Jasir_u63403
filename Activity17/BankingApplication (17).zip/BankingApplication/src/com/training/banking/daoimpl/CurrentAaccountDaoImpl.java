/**
 * CurrentAaccountDaoImpl
 * 
 * Implementation for Current Account DAO operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.banking.entity.CurrentAccount;
import com.training.banking.repository.CurrentAccountDao;

/**
 * Implementation for LaonAccount DAO
*/
public class CurrentAaccountDaoImpl implements CurrentAccountDao {

	List currentAccountList;
	/**
	 * Constructor LaonAccount DAO
	*/
	public CurrentAaccountDaoImpl() {
		currentAccountList = new ArrayList<CurrentAccount>();
		CurrentAccount account1 = new  CurrentAccount(123456730, "Sabith", 10000.0f, 5000.0f);
		CurrentAccount account2 = new  CurrentAccount(123456731, "Arun", 15000.0f, 8000.0f);
		CurrentAccount account3 = new  CurrentAccount(123456732, "Anoop", 20000.0f, 6000.0f);
		CurrentAccount account4 = new  CurrentAccount(123456734, "Hisam", 11000.0f, 7000.0f);
		
		currentAccountList.add(account1);
		currentAccountList.add(account2);
		currentAccountList.add(account3);
		currentAccountList.add(account4);
	}
	
	/**
	 * Implementation for get Current Accounts
	*/
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		return currentAccountList;
	}

	/**
	 * Implementation for get one Current Account by account numbers
	*/
	@Override
	public CurrentAccount getCurrentAccountByAccountNum(int acNumber) {
		CurrentAccount currentAccount =null;
		
		Iterator<CurrentAccount>   iterator = currentAccountList.iterator();
		
		while(iterator.hasNext()){
			
			CurrentAccount cuurentAc = iterator.next();
			
			if(cuurentAc.getAccountNumber()==acNumber){
				
				currentAccount=cuurentAc;
				
			}

		}

		return currentAccount;
	}

	/**
	 * Implementation for delete a Current Account by account numbers
	*/
	@Override
	public void deleteCurrentAccount(int acNumber) {
		
		for(int i=0; i< currentAccountList.size(); i++){
			
			CurrentAccount cuurentAc =(CurrentAccount)currentAccountList.get(i);
			
			if(cuurentAc.getAccountNumber()==acNumber){
				
				currentAccountList.remove(i);
				
			}
			
		}

	}

	
}
