package com.training.lambda.services;

import com.training.lambda.interfaces.CheckValue;
import com.training.lambda.interfaces.DisplayResult;
import com.training.lambda.interfaces.NumCalculator;
import com.training.lambda.interfaces.Test;

public class ExecuteLambda {

	public static void main(String[] args) {
		
		/*Exercise 1*/
		System.out.println("Exercise 1\n");
		
		int a =21;
		CheckValue checkValue = (n)->(n%2 !=0);
		
		if (checkValue.check(a)) {
			System.out.println(a+" is an odd number  ");
			}
		else {
			System.out.println(a+" is an even number");
			}
		
		/*Exercise 2*/
		System.out.println("\nExercise 2\n");

		NumCalculator numCalc = (x,y)-> x+y;
		int x=10;
		int y=20;
		System.out.println("Addition of "+x+" and "+y+" ="+numCalc.getValue(x, y));
		
		/*Exercise 3*/
		System.out.println("\nExercise 3\n");
		
		DisplayResult disply = (s)->{System.out.println(s);};
		disply.display("This is third exercise");
		
		/*Exercise 4*/
		System.out.println("\nExercise 4\n");
		
		Test test = ()->{System.out.println("Hello world");};
		test.test();
		}
}
