package com.training.lambda.interfaces;

public interface NumCalculator {

	public int getValue(int a,int b);
}
