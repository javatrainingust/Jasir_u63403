package com.training.lambda.interfaces;

public interface CheckValue {
	
	public boolean check(int n);
}
