package com.training.lambda.interfaces;

public interface DisplayResult {

	public void display(String s);
}
