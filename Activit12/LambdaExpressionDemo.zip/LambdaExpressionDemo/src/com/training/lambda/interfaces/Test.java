package com.training.lambda.interfaces;

public interface Test {

	public void test();

}
