package com.training.banking.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AccountTest {

	@Test
	void testWithdrawMoney() {
		
		float expectedValue = 8000;
		Account acount = new Account();
		acount.withdrawMoney(2000);
		float actualValue = acount.getAccountBalance();
		assertEquals(expectedValue, actualValue);
		
		
	}

}
