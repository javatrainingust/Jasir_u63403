package com.training.banking.entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.training.banking.interfaces.AccountRenew;

class FDAccountTest {

	@Test
	void testAutoRenewal() {
		
		int expectedValue = 2021;
		FDAccount fdac1 = new FDAccount();
		fdac1.autoRenew(1);
		int actualValue = fdac1.getMaturity_date();
		assertEquals(expectedValue, actualValue);
	}

}
