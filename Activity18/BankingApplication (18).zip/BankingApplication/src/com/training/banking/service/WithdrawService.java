/**
 * 
 */
package com.training.banking.service;

import com.training.banking.entity.FDAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.interfaces.AccountRenew;
import com.training.banking.util.InterestCalculator;
/**
 * 
 * @author Jasir
 *
 */
public class WithdrawService {

	public static void main(String[] args) {
		
		SBAccount sbac = new SBAccount();
		sbac.setRate(.5f);
		sbac.setAccountHolderName("raj");
		sbac.setAccountNumber(123654);
		sbac.setTime(1);
		InterestCalculator calculator = new InterestCalculator();
		//sbac.calculateInterest(calculator);
		
		AccountRenew fdac = new FDAccount();
		fdac.autoRenew(1);
		//fdac.calculateInterest(calculator);
	}

}
