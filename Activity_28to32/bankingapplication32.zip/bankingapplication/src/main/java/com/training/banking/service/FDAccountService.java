/**
 * FDAccountService
 * 
 * Business logics for FDAccount 
 *
 * 06/10/2020
 * 
*/
package com.training.banking.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.banking.daoimpl.FDAccountDaoImpl;
import com.training.banking.entity.CurrentAccount;
import com.training.banking.entity.FDAccount;
import com.training.banking.repository.FDAccountDao;
import com.training.banking.util.CurrentAccountComparator;
import com.training.banking.util.FDAccountComparator;
/**
 * Service class for FD account
 */
@Service
public class FDAccountService {
	@Autowired
	FDAccountDao fdAccountDao;
	
	/**
	 * Constructor for FD account Service
	 */
	public FDAccountService(){
			
		//fdAccountDao = new FDAccountDaoImpl();
			
		} 
	
	/**
	 * Fetch all FD Accounts
	 */
	public List<FDAccount> getAllFixedAccounts() {
	
		List fdAccountList = fdAccountDao.getAllFixedAccounts();
		
		Iterator<FDAccount> iterator = fdAccountList.iterator();
		
		while(iterator.hasNext()){
			
			FDAccount fd = iterator.next();
			
			System.out.println("Name = "+fd.getAccountHolderName());
			System.out.println("Account Number ="+fd.getAccountNumber());
			System.out.println("Account Balance = "+fd.getAccountBalance());
			
			}			

		return fdAccountList;
		
	}
		
	/**
	 * Fetch one Fixed account by its account number
	 */
	public FDAccount getFdAccountByAccountNum(int accountNumber) {
		
		FDAccount fd = fdAccountDao.getFdAccountByAccountNum(accountNumber);
				
		System.out.println("Name = "+fd.getAccountHolderName());
		System.out.println("Account Number ="+fd.getAccountNumber());
		System.out.println("Account Balance = "+fd.getAccountBalance());
		
		return fd;
		
	}	
	
	/**
	 * Remove one Fixed account by its account number
	 */	
	public void deleteFixedAccount(int accountNumber) {
		
		fdAccountDao.deleteFixedAccount(accountNumber);
		
	}	
	/**
	 * Sort Accounts by account holder names using Stream
	 */
	
	public List<FDAccount>	getAllFixedAccountsSortedByNames(){
		
		
		List<FDAccount> fdAccount = fdAccountDao.getAllFixedAccounts();
		
		//Collections.sort(fdAccount);
		
		Stream<FDAccount> fdAcStream = fdAccount.stream();
		
		Stream<FDAccount> sortedStream = fdAcStream.sorted();
		
		List sortedFdAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<FDAccount> iterator = sortedFdAccount.iterator();
		
		while(iterator.hasNext()){
			
			FDAccount fdAc = iterator.next();
			System.out.println("Name = "+fdAc.getAccountHolderName());
			System.out.println("Account Number ="+fdAc.getAccountNumber());
			System.out.println("Account Balance = "+fdAc.getAccountBalance());			
			
			}			

		return fdAccount;
	}
	/**
	 * Sort Accounts by account balance using Stream
	 */
	public List<FDAccount>	getAllFixedAccountsSortedByBalance(){
		
		
		List<FDAccount> fdAccount = fdAccountDao.getAllFixedAccounts();
		
		//Collections.sort(fdAccount,new FDAccountComparator());
		Stream<FDAccount> fdAcStream = fdAccount.stream();
		
		Stream<FDAccount> sortedStream = fdAcStream.sorted(new FDAccountComparator());
		
		List sortedFdAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<FDAccount> iterator = sortedFdAccount.iterator();
		
		
		while(iterator.hasNext()){
			
			FDAccount fdAc = iterator.next();
			System.out.println("Name = "+fdAc.getAccountHolderName());
			System.out.println("Account Number ="+fdAc.getAccountNumber());
			System.out.println("Account Balance = "+fdAc.getAccountBalance());			
			
			}			

		return fdAccount;
	}
	/**
	 * service for add fixed account
	 * @param fdAccount
	 */
	public void addFixedAccount(FDAccount fdAccount) {
		
		boolean isAdded = fdAccountDao.addFixedAccount(fdAccount);
		
		if(!isAdded){
			
			System.out.println("The Fixed account already exist");
		}
		else{
			System.out.println("The Fixed account successfully added");
			
		}
	}
	/**
	 * service for update fixed account
	 * @param fdAccount
	 */
	public void updateFixedAccount(FDAccount fdAccount){
		
		fdAccountDao.updateFixedAccount(fdAccount);
	}
}
