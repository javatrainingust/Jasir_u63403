/***
 * ClassName:LoanAccountController
 * 
 * Description:Class for getting all the loan Account details
 * 
 * Date-15-10-2020
 */

package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.banking.entity.LoanAccount;
import com.training.banking.service.LoanAccountService;




@Controller
public class LoanAccountController {
	
	/*LoanAccount service class object is created using autowired annotation*/

	@Autowired
	private LoanAccountService loanAccountService;
	

	/***
	 * Url ending with /Loan mapped to get all deposite method
	 */
	@RequestMapping("/Loan")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallLoanAccount");
	List<LoanAccount> LoanDepositeList =loanAccountService.getAllLoanAccounts();	
		model.addAttribute("loanList",LoanDepositeList);
		return "loanDepositeList";
	}
	

/***
* Method for getting the details of an Loan account by account number and assignig
*/

	@RequestMapping("/viewLoan")
	public String getSbAccount(@RequestParam("id") String id,Model model)
	{
		LoanAccount loanAccount = loanAccountService.getLoanAccountByAccountNum(Integer.parseInt(id));
		
	model.addAttribute("loanAccount", loanAccount);
		return "viewLoanAccount";
	}
	

}
