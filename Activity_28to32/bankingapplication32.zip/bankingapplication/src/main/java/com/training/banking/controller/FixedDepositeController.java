/***
 * ClassName:FixedDepositeController
 * 
 * Description:Class for getting all the fixedDeposite details
 * 
 * Date-15-10-2020
 */

package com.training.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.banking.entity.FDAccount;
import com.training.banking.service.FDAccountService;



@Controller
public class FixedDepositeController {
	
	/*FixedDeposite service class object is created using autowired annotation*/
	
	@Autowired
	private FDAccountService fdservice;

	/***
	 * Url ending with /fixeddeposite mapped to get all deposite method
	 */
	
	@RequestMapping("/fixeddeposite")
	public String getAllDeposite(Model model)
	{
		System.out.println("Inside the controller getallFixedDeposite");
	List<FDAccount> fixedDepositeList =fdservice.getAllFixedAccounts();	
		model.addAttribute("FdList",fixedDepositeList);
		
		return "fixedDepositeList";
	}
	

/***
* Method for getting the details of an Fixed account by account number and assignig
* 
* to model
*
*/
	
	@RequestMapping("/viewFdAccount")
	public String getFdAccount(@RequestParam("id") String id,Model model){
		
		FDAccount fdDeposite= fdservice.getFdAccountByAccountNum(Integer.parseInt(id));
		
		model.addAttribute("fixedDeposite",fdDeposite);
		
		return "viewFixedDeposite";
	}
	
}
