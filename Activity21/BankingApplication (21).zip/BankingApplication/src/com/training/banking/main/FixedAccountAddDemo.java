/**
 * FixedAccountAddDemo
 */
package com.training.banking.main;

import com.training.banking.entity.FDAccount;
import com.training.banking.service.FDAccountService;

public class FixedAccountAddDemo {

	public static void main(String[] args) {
		
		FDAccountService service = new FDAccountService();
		service.addFixedAccount(new FDAccount(123456789, "Albin Jose", 10000.0f, 2, true, 2022));
		service.addFixedAccount(new FDAccount(123456790, "Manohar k k", 15000.0f, 1, true, 2021));
		service.addFixedAccount(new FDAccount(123456791, "Raguvaran", 20000.0f, 3, true, 2023));
		service.addFixedAccount(new FDAccount(123456792, "Bunny P", 18000.0f, 5, true, 2025));
		service.addFixedAccount(new FDAccount(123456791, "Raguvaran kss", 200000.0f, 3, true, 2023));
		
		System.out.println("Printing all Fixed Accounts");	
		service.getAllFixedAccounts();
		System.out.println("---------------------------------------------");	
		service.updateFixedAccount(new FDAccount(123456792, "Bunny P benny", 18000.0f, 5, true, 2025));
		
		System.out.println("Printing all updated Fixed Accounts");	
		
		service.getAllFixedAccounts();

	}

}
