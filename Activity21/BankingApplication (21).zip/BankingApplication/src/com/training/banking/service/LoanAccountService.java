/**
 * LaonAccountService
 * 
 * Business logics for Loan Account 
 *
 * 06/10/2020
 * 
 */
package com.training.banking.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.training.banking.daoimpl.LoanAccountDaoImpl;
import com.training.banking.daoimpl.SBAccountDaoImpl;
import com.training.banking.entity.FDAccount;
import com.training.banking.entity.LoanAccount;
import com.training.banking.entity.SBAccount;
import com.training.banking.repository.LoanAccountDao;
import com.training.banking.repository.SBAccountDAo;
import com.training.banking.util.LoanAccountComparator;

/**
 * Service class for Loan account 
 */
public class LoanAccountService {

	LoanAccountDao loanAccountDao;
	
	/**
	 * Constructor for Loan account Service
	 */
	public LoanAccountService() {

		loanAccountDao = new LoanAccountDaoImpl();
	}

	/**
	 * Fetch all Loan Accounts 
	 */
	public List<LoanAccount> getAllLoanAccounts() {

		List laonAccountList = loanAccountDao.getAllLoanAccounts();

		Iterator<LoanAccount> iterator = laonAccountList.iterator();

		while (iterator.hasNext()) {

			LoanAccount loanAaccount = iterator.next();

			System.out.println("Name = " + loanAaccount.getAccountHolderName());
			System.out.println("Account Number =" + loanAaccount.getAccountNumber());
			System.out.println("Account Balance = " + loanAaccount.getAccountBalance());

		}

		return laonAccountList;

	}

	/** 
	 * Fetch one Loan account by its account number 
	 */
	public LoanAccount getLoanAccountByAccountNum(int accountNumber) {

		LoanAccount sb = loanAccountDao.getLaonAccountByAccountNum(accountNumber);

		System.out.println("Name = " + sb.getAccountHolderName());
		System.out.println("Account Number =" + sb.getAccountNumber());
		System.out.println("Account Balance = " + sb.getAccountBalance());

		return sb;

	}

	/** 
	 * Remove one Loan account by its account number 
	 */
	public void deleteLoanAccount(int accountNumber) {

		loanAccountDao.deleteLaonAccount(accountNumber);

	}
	/**
	 * Sort Accounts by account holder names using Stream
	 */
	public List<LoanAccount>getAllLoanAccountsSortedByNames(){
		
		List<LoanAccount> loanAccount = loanAccountDao.getAllLoanAccounts();
		
		//Collections.sort(loanAccount);
		
		Stream<LoanAccount> loanAcStream = loanAccount.stream();
		
		Stream<LoanAccount> sortedStream = loanAcStream.sorted();
		
		List sortedLoanAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<LoanAccount> iterator = sortedLoanAccount.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount loaAc = iterator.next();
			System.out.println("Name = "+loaAc.getAccountHolderName());
			System.out.println("Account Number ="+loaAc.getAccountNumber());
			System.out.println("Account Balance = "+loaAc.getAccountBalance());			
			
			}			

		return loanAccount;
	}
	/**
	 * Sort Accounts by account balance using Stream
	 */
	public List<LoanAccount>getAllLoanAccountsSortedByBalance(){
		
		List<LoanAccount> loanAccount = loanAccountDao.getAllLoanAccounts();
		
		//Collections.sort(loanAccount,new LoanAccountComparator());
		
		Stream<LoanAccount> loanAcStream = loanAccount.stream();
		
		Stream<LoanAccount> sortedStream = loanAcStream.sorted(new LoanAccountComparator());
		
		List sortedLoanAccount = sortedStream.collect(Collectors.toList());
		
		Iterator<LoanAccount> iterator = sortedLoanAccount.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount loaAc = iterator.next();
			System.out.println("Name = "+loaAc.getAccountHolderName());
			System.out.println("Account Number ="+loaAc.getAccountNumber());
			System.out.println("Account Balance = "+loaAc.getAccountBalance());			
			
			}			

		return loanAccount;
	}
	/**
	 * service for add loan account
	 * @param loanAccount
	 */
	public void addLoanAccount(LoanAccount loanAccount) {
		
		boolean isAdded = loanAccountDao.addLoanAccount(loanAccount);
		
		if(!isAdded){
			
			System.out.println("The Loan account already exist");
		}
		else{
			System.out.println("The Loan account successfully added");
			
		}
	}
	/**
	 * service for update loan account
	 * @param loanAccount
	 */
	public void updateLoanAccount(LoanAccount loanAccount){
		
		loanAccountDao.updateLoanAccount(loanAccount);
	}

}
