/**
 * FDAccountDaoImpl
 * 
 * Implementation for Loan Account DAO operations
 *
 * 06/10/2020
 * 
*/
package com.training.banking.daoimpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.banking.entity.FDAccount;
import com.training.banking.entity.LoanAccount;
import com.training.banking.repository.LoanAccountDao;

/**
 * Implementation for LaonAccount DAO
*/
public class LoanAccountDaoImpl implements LoanAccountDao {

	List loanAccountList;
	private Set loanAccountSet;
	/**
	 * Constructor for LaonAccount DAO
	*/
	public LoanAccountDaoImpl() {
		loanAccountList = new ArrayList<LoanAccount>();
		loanAccountSet = new HashSet<LoanAccount>();
		
		  LoanAccount account1 = new LoanAccount(123456720, "Jaleel", 45000.15f,
		  "Educational", 2, 100000.0f); LoanAccount account2 = new
		  LoanAccount(123456721, "Nishil", 60000.15f, "Home", 5, 1000000.0f);
		  LoanAccount account3 = new LoanAccount(123456722, "Ashker", 25000.15f, "Car",
		  4, 500000.0f); LoanAccount account4 = new LoanAccount(123456723, "Fathima",
		  75000.15f, "Educational", 2, 100000.0f);
		  
		  loanAccountList.add(account1); loanAccountList.add(account2);
		  loanAccountList.add(account3); loanAccountList.add(account4);
		 
	}
	
	/**
	 * Implementation for get Laon Accounts
	*/
	@Override
	public List<LoanAccount> getAllLoanAccounts() {
		return loanAccountList;
	}

	/**
	 * Implementation for get one Loan Account by account numbers
	*/
	@Override
	public LoanAccount getLaonAccountByAccountNum(int acNumber) {
		LoanAccount loanAccount =null;
		
		Iterator<LoanAccount>   iterator = loanAccountList.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount loanAc = iterator.next();
			
			if(loanAc.getAccountNumber()==acNumber){
				
				loanAccount=loanAc;
				
			}
				
		}

		return loanAccount;
	}

	/**
	 * Implementation for delete a Loan Account by account numbers
	 * 
	*/
	@Override
	public void deleteLaonAccount(int acNumber) {
		
		for(int i=0; i< loanAccountList.size(); i++){
			
			LoanAccount loan =(LoanAccount)loanAccountList.get(i);
			
			if(loan.getAccountNumber()==acNumber){
				
				loanAccountList.remove(i);
				
			}
			
		}

	}
	/**
	 *  method for add Loan account to SET to avoid duplication and then add to List 
	 */
	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
		boolean isAdded = loanAccountSet.add(loanAccount);
		if (isAdded) {
			loanAccountList.add(loanAccount);
		}
		return isAdded;
	}
	/**
	 * update loan account
	 */
	@Override
	public void updateLoanAccount(LoanAccount loanAccount) {
		Iterator iterator = loanAccountList.iterator();
		
		while(iterator.hasNext()){
			
			LoanAccount la =(LoanAccount)iterator.next();
			
			if(la.getAccountNumber()==loanAccount.getAccountNumber()){
				
			la.setAccountHolderName(loanAccount.getAccountHolderName());
			la.setAccountNumber(loanAccount.getAccountNumber());
			la.setAccountBalance(loanAccount.getAccountBalance());
				
			}
		}
		
	}

	
}
