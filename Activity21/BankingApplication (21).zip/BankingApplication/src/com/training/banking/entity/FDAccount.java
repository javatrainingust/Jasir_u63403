/**
 * InterestCalculator
 * 
 * Entity class for handle the Fixed deposit account
 *
 * 28/09/2020
 * 
 */
package com.training.banking.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.training.banking.interfaces.ICalculateInterest;

import com.training.banking.interfaces.AccountRenew;

/**
 * sub class for FD account derived from account class that uses a interface for renew 
 */
public class FDAccount extends Account implements AccountRenew,Comparable<FDAccount> {
	
	private int tenure ;
	private boolean autoRenewal;
	private float rate = 0.4f;
	private int maturity_date;
	private float interest=13.5f;

	/**
	 * Parameterized constructor
	*/
	public FDAccount(int accountNumber, String accountHolderName, float accountBalance, int tenure, boolean autoRenewal,
			int maturity_date) {
		super(accountNumber, accountHolderName, accountBalance);
		this.tenure = tenure;
		this.autoRenewal = autoRenewal;
		this.maturity_date = maturity_date;
	}

	/**
	 * return the class obj values as string
	*/
	@Override
	public String toString() {
		return "FDAccount [tenure=" + tenure + ", autoRenewal=" + autoRenewal + ", rate=" + rate + ", maturity_date="
				+ maturity_date + ", interest=" + interest + "]";
	}

	/**
	 * Default Constructor
	 */
	public FDAccount() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * get the value of interest
	*/
	public float getInterest() {
		return interest;
	}

	/**
	 * get the value of rate
	*/
	public float getRate() {
		return rate;
	}
	

	/**
	 * assign the value to rate
	*/
	public void setRate(float rate) {
		this.rate = rate;
	}
	
	
	/**
	 * get the value of tenure
	*/
	public int getTenure() {
		return tenure;
	}
	
	/**
	 * assign the value to tenure
	*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	
	/**
	 * get maturity date
	 */
	public int getMaturity_date() {
		return maturity_date;
	}
	
	/**
	 * get the renewal value
	*/
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	
	/**
	 * assign the value to renewal
	*/
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	/**
	 * overriding method for calculate interest
	*/
	public void calculateInterest(ICalculateInterest calcs) {
		
		this.interest = calcs.calculateInterest(getAccountBalance(),rate,tenure);
		System.out.println("your FDAccount will have RS "+this.interest+ " as interest  with rate "+rate);
		
	}
	/**
	 * automatically renew when meet the maturity date
	*/
	@Override
	public void autoRenew(int tenure) {
		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Calendar calobj = Calendar.getInstance();
		Calendar valid_date = Calendar.getInstance();
		valid_date.set(2020, 9, 1);
		/*check auto renewal is true*/ 
		System.out.println(this.autoRenewal);
		if(this.autoRenewal) {
			if (df.format(valid_date.getTime()).compareTo(df.format(calobj.getTime()))==0) {
				valid_date.add(Calendar.YEAR,tenure);
				this.maturity_date = valid_date.get(1);
				System.out.println("Your FD account got automatically renewed. new maturity date is "+getMaturity_date());
			}
		}
		
	}
	/**
	 * Comparable implementation for sorting
	*/
	@Override
	public int compareTo(FDAccount o) {
	
		return this.getAccountHolderName().compareTo(o.getAccountHolderName());
	}

}
