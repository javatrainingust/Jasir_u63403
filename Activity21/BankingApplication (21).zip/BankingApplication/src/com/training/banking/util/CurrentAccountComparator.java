/**
 * CurrentAccountComparator
 * 
 * Sort current account based account balance
 * 
 * 07/10/2020
 */
package com.training.banking.util;

import java.util.Comparator;

import com.training.banking.entity.CurrentAccount;
/***
 * 
 * @author Jasir
 * Comparator class fo sort based on account balance 
 */
public class CurrentAccountComparator implements Comparator<CurrentAccount> {

	/**
	 * Implementation for sort by account account balance
	 */
	@Override
	public int compare(CurrentAccount o1, CurrentAccount o2) {
		
		return (int) (o1.getAccountBalance()-o2.getAccountBalance());
	}

}
