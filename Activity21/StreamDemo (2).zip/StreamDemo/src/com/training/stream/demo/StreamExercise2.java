/**
 * StreamExercise2
 * Stream sorted example
 * 09/10/2020
 */
package com.training.stream.demo;

import java.util.stream.Stream;
/**
 * 
 * @author Jasir
 * stream class for sort string values 
 */
public class StreamExercise2 {

	public static void main(String[] args) {
		
		Stream<String> streamStudents = Stream.of("Manohar","Allan","Zhakir","Bala","Ramesh").sorted();
		System.out.println("Sorted names\n");
		streamStudents.forEach((e)->{System.out.println(e);});
	}

}
