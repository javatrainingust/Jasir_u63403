/**
 * StreamExercise3
 * Example for sort class object stream
 * 09/10/2020
 */
package com.training.stream.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.training.stream.entity.Cat;
/**
 * 
 * @author Jasir
 * Sort cat object stream using Comparable
 */
public class StreamExercise3 {

	public static void main(String[] args) {
	
		Cat cat = new Cat("Lilly", 3);
		Cat cat1 = new Cat("yellow",2 );
		Cat cat2 = new Cat("Ado", 1);
		Cat cat3 = new Cat("Samer", 5);
		Cat cat4 = new Cat("Minn", 4);
		
		List<Cat> catList = new ArrayList<Cat>();
		catList.add(cat);
		catList.add(cat1);
		catList.add(cat2);
		catList.add(cat3);
		catList.add(cat4);

		Stream<Cat> catStream = catList.stream();
		
		Stream<Cat> sortedCatStream = catStream.sorted();
		
		sortedCatStream.forEach((e)->System.out.println(e));
		
	}

}
