/**
 * StreamExercise1
 * stream example for map, filter and reduce
 * 09/10/2020
 */
package com.training.stream.demo;

import java.util.stream.Stream;

/**
 * 
 * @author Jasir
 * stream to work with map, filter and reduce
 */
public class StreamExercise1 {

	public static void main(String[] args) {
		
		Stream<Integer> streamNumbers = Stream.of(1,2,3,4,5,6,7,8,9);
		
		Long number = streamNumbers.map((n)->(n*2)).filter((n)->(n>10)).count();
		
		System.out.println("Numbers grater than 10 is "+number);

	}

}
