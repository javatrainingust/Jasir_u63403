/**
 * Organizer
 * 
 * Organizer for Spring World Talent Competition
 * 
 * 12/10/2020
 */
package com.training.ioc.bean;
/**
 * 
 * @author Jasir
 * Bean class for organizer
 */
public class Organizer {

	/**
	 * default constructor 
	 */
	public Organizer() {
		
		System.out.println("Inside Organizer constructor");
	}
	
	/**
	 * welcome the participant
	 */
	public void sayGreetings() {
		System.out.println("Welcome to the talent competion");
	}
}
